package cs3500.reversi.controller;

import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.shapes.CellShape;
import cs3500.reversi.utils.ICoords;

/**
 * Represents the interface for all the features a player has access to.
 */
public interface PlayerFeatures<T extends CellShape> {

  /**
   * Passes the current player's turn.
   */
  void pass();

  /**
   * Places the current's player token color at the given hexcoord.
   * @param hc a cell's hex coordinate
   */
  void placeToken(ICoords<T> hc);

  /**
   * Gets the read only model so that the player can observe the model.
   * @return the read only model
   */
  ReversiROM getROM();
}
