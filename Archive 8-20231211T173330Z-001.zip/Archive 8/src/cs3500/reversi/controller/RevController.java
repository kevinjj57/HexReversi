package cs3500.reversi.controller;

import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.player.IPlayer;
import cs3500.reversi.utils.ICoords;
import cs3500.reversi.utils.TokenStatus;
import cs3500.reversi.view.RevGUI;

/**
 * The controller for the game of Reversi. Delegates to the view and model to allow a fully
 * playable game of Reversi against an AI or another human.
 */
public class RevController implements IController {

  ReversiModel model;
  RevGUI view;
  IPlayer player;
  boolean isTurn;
  TokenStatus color;

  /**
   * Constructor for RevController.
   * @param model the model
   * @param player the player
   * @param view the view
   */
  public RevController(ReversiModel model, IPlayer player, RevGUI view) {
    this.model = model;
    this.view = view;
    this.player = player;
    model.addMoveListener(this);
    player.assignController(this);
    view.setCommandListener(this);
    this.view.showMessage("You are " + getColor());
    this.view.render();
  }


  /**
   * Getting a readOnly version of the model that this controller is playing on.
   * @return the model in the identity of its readOnly interface so it is not to be mutated.
   */
  @Override
  public ReversiROM getROM() {
    return model;
  }

  @Override
  public void assignColor(TokenStatus color) {
    if (this.color != null) {
      throw new IllegalStateException("Color already assigned");
    }
    if (color == TokenStatus.EMPTY) {
      throw new IllegalArgumentException();
    }
    this.color = color;
  }

  @Override
  public TokenStatus getColor() {
    if (this.color == null) {
      throw new IllegalStateException("Color not yet assigned");
    }
    return this.color;
  }

  @Override
  public void yourTurn() {
    if (isTurn) {
      throw new IllegalStateException("Already my turn");
    }
    isTurn = true;
    view.setFocus();
    player.yourTurn();
  }

  @Override
  public void refreshAll() {
    view.render();
  }

  @Override
  public void gameOver() {
    StringBuffer ans = new StringBuffer();
    if (model.getScoreWhite() == model.getScoreBlack()) {
      ans.append("Tie! ");
    } else {
      if (model.getScoreWhite() > model.getScoreBlack()) {
        ans.append("White Wins! ");
      } else {
        ans.append("Black Wins! ");
      }
    }
    ans.append("Black: " + model.getScoreBlack() + ". White: " + model.getScoreWhite() + ".");
    view.showMessage(ans.toString());
  }

  @Override
  public void pass() {
    if (!isTurn) {
      view.showMessage("Not your turn");
    } else {
      try {
        isTurn = false;
        view.removeFocus();
        model.pass();
      } catch (IllegalStateException e) {
        isTurn = true;
        view.setFocus();
        view.showMessage(e.getMessage());
      }
    }
    view.render();
  }

  @Override
  public void placeToken(ICoords hc) {
    if (!isTurn) {
      view.showMessage("Not your turn");
    } else {
      try {
        isTurn = false;
        view.removeFocus();
        model.placeToken(hc);
      } catch (IllegalStateException e) {
        isTurn = true;
        view.setFocus();
        view.showMessage(e.getMessage());
      }
    }
    view.render();
  }
}
