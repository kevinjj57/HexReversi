package cs3500.reversi.utils;

import java.util.Objects;

import cs3500.reversi.shapes.Square;

/**
 * Represents the coordinate system for a square game of Reversi being x, y.
 */
public final class SquareCoords implements ICoords<Square> {

  int x;
  int y;

  /**
   * Default constructor for square coordinate system.
   * @param x the x coordinate
   * @param y the y coordinate
   */
  public SquareCoords(int x, int y) {
    this.x = x;
    this.y = y;
  }


  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof SquareCoords) {
      SquareCoords object = (SquareCoords) o;
      return object.x == this.x && object.y == this.y;
    } else {
      return false;
    }
  }

  @Override
  public int hashCode() {
    return Objects.hash(x, y);
  }

  @Override
  public int getFirst() {
    return x;
  }

  @Override
  public int getSecond() {
    return y;
  }
}
