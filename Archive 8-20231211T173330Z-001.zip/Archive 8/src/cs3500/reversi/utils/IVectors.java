package cs3500.reversi.utils;


/**
 * Empty interface to represent generic vectors.
 */
public interface IVectors {

}
