package cs3500.reversi.utils;

import cs3500.reversi.shapes.CellShape;

/**
 * A generic coordinate representation of type CellShape.
 * @param <T> a cell shape
 */
public interface ICoords<T extends CellShape> {

  /**
   * Returns the first integer of a coordinate.
   * @return the first coordinate
   */
  int getFirst();

  /**
   * Returns the second integer of a coordinate.
   * @return the second coordinate
   */
  int getSecond();
}
