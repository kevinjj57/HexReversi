package cs3500.reversi.player;

import cs3500.reversi.controller.PlayerFeatures;
import cs3500.reversi.utils.ICoords;
import cs3500.reversi.utils.TokenStatus;

/**
 * Represents the default behavior for any player, meaning a human OR an AI.
 */
public abstract class StandardPlayer implements IPlayer {
  TokenStatus color;
  PlayerFeatures playerFeatures;

  @Override
  public void assignColor(TokenStatus gc) {
    this.color = gc;
  }

  @Override
  public void assignController(PlayerFeatures feat) {
    this.playerFeatures = feat;
  }

  @Override
  public TokenStatus getColor() {
    checkGameStartedCorrectly();
    return this.color;
  }

  @Override
  public void placeToken(ICoords coord) {
    checkGameStartedCorrectly();
    playerFeatures.placeToken(coord);
  }

  @Override
  public void pass() {
    checkGameStartedCorrectly();
    playerFeatures.pass();
  }

  @Override
  public void yourTurn() {
    checkGameStartedCorrectly();
  }

  protected void checkGameStartedCorrectly() {
    if (/*this.color == null|| */this.playerFeatures == null) {
      throw new IllegalStateException("Game must be instantiated before making moves");
    }
  }
}
