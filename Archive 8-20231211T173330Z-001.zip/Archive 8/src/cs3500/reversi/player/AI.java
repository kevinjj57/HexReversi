package cs3500.reversi.player;

import java.util.List;

import cs3500.reversi.strategy.PlaceStrategy;
import cs3500.reversi.utils.ICoords;

/**
 * Represents an AI player for a game of Reversi. AI's choose moves based on the strategies passed
 * to them or defaults to the first available most that is closest to top left.
 */
public class AI extends StandardPlayer {
  PlaceStrategy strategies;


  /**
   * Constructor for AI that sets the AI strategy to the parameters.
   * @param strat an AI place strategy
   */
  public AI(PlaceStrategy strat) {
    this.strategies = strat;
  }

  /**
   * Default constructor an AI. If no strategies are given, AI picks the first valid move
   */
  public AI() {
    this.strategies = null;
  }

  // picks the best move from the given list of strategies for the AI
  @Override
  public void yourTurn() {
    super.yourTurn();
    List<ICoords> validMoves = playerFeatures.getROM().getPossibleMoves();
    if (strategies != null) {
      validMoves = strategies.getValidMoves(playerFeatures.getROM(), validMoves);
    }
    if (validMoves.size() == 0) {
      pass();
    } else {
      placeToken(validMoves.get(0));
    }
  }
}
