package cs3500.reversi.shapes;

import java.util.ArrayList;
import java.util.List;

import cs3500.reversi.board.IBoard;
import cs3500.reversi.board.SquareBoard;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.model.SquareReversi;
import cs3500.reversi.utils.ICoords;
import cs3500.reversi.utils.IVectors;
import cs3500.reversi.utils.SquareCoords;
import cs3500.reversi.view.RevGUI;
import cs3500.reversi.view.SquareGUI;

/**
 * Represents the specific cell shape Square for a Square Reversi.
 */
public class Square implements CellShape {

  @Override
  public List<ICoords> getVectors() {
    List<ICoords> ans = new ArrayList<>();
    for (SquareVecs sv : SquareVecs.values()) {
      ans.add(makeCoord(sv.xChange, sv.yChange));
    }
    return ans;
  }

  @Override
  public ICoords makeCoord(int coord1, int coord2) {
    return new SquareCoords(coord1, coord2);
  }

  @Override
  public IBoard buildBoard(int sideLength) {
    return new SquareBoard(sideLength);
  }

  @Override
  public ReversiModel buildModel(int sideLength) {
    return new SquareReversi(sideLength);
  }

  @Override
  public RevGUI makeGUI(ReversiROM model) {
    return new SquareGUI(1000, 1000, model);
  }


  /**
   * Represents the different vectors for a Square shape.
   */
  public enum SquareVecs implements IVectors {
    UP(0, 1),
    UPLEFT(-1, 1),
    LEFT(-1, 0),
    DOWNLEFT(-1, -1),
    DOWN(0, -1),
    DOWNRIGHT(1, -1),
    RIGHT(1, 0),
    UPRIGHT(1, 1);

    public final int xChange;
    public final int yChange;

    /**
     * Default constructor for a HexVector.
     *
     * @param xChange the change in the q axis
     * @param yChange the change in the r axis
     */
    SquareVecs(int xChange, int yChange) {
      this.xChange = xChange;
      this.yChange = yChange;
    }
  }
}
