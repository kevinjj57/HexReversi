package cs3500.reversi.shapes;


import java.util.ArrayList;
import java.util.List;

import cs3500.reversi.board.HexBoard;
import cs3500.reversi.board.IBoard;
import cs3500.reversi.model.HexReversi;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.utils.HexCoords;
import cs3500.reversi.utils.ICoords;
import cs3500.reversi.utils.IVectors;
import cs3500.reversi.view.HexGUI;
import cs3500.reversi.view.RevGUI;

/**
 * Represents the specific cell shape Hex for hexagon Reversi.
 */
public class Hex implements CellShape {


  @Override
  public List<ICoords> getVectors() {
    List<ICoords> ans = new ArrayList<>();
    for (HexVectors hv : HexVectors.values()) {
      ans.add(makeCoord(hv.qChange, hv.rChange));
    }
    return ans;
  }

  @Override
  public IBoard buildBoard(int sideLength) {
    return new HexBoard(sideLength);
  }

  @Override
  public ReversiModel buildModel(int sideLength) {
    return new HexReversi(sideLength);
  }

  @Override
  public RevGUI makeGUI(ReversiROM model) {
    return new HexGUI(1000, 1000, model);
  }



  @Override
  public ICoords makeCoord(int coord1, int coord2) {
    return new HexCoords(coord1, coord2);
  }

  /**
   * Vectors representing the change in r & q values that are required to traverse one unit
   * in each of the six allowable directions.
   */
  public enum HexVectors implements IVectors {
    UPLEFT(0, -1),
    LEFT(-1, 0),
    DOWNLEFT(-1, 1),
    DOWNRIGHT(0, 1),
    RIGHT(1, 0),
    UPRIGHT(1, -1);

    public final int qChange;
    public final int rChange;

    /**
     * Default constructor for a HexVector.
     * @param qChange the change in the q axis
     * @param rChange the change in the r axis
     */
    HexVectors(int qChange, int rChange) {
      this.qChange = qChange;
      this.rChange = rChange;
    }
  }
}
