package cs3500.reversi.shapes;

import java.util.List;

import cs3500.reversi.board.IBoard;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.utils.ICoords;
import cs3500.reversi.view.RevGUI;

/**
 * Represents a specific shape for a cell in a game of Reversi. Provides methods to allow any
 * shape to work witbh our MVC design.
 */
public interface CellShape {

  /**
   * Returns all the available vectors for a specific cell shape.
   * @return all shape specific vectors
   */
  List<ICoords> getVectors();

  /**
   * Creates an ICoord from a specific shape's coordinates.
   * @param coord1 first coordinate
   * @param coord2 second coordinate
   * @return the ICoord version of the shape coordinate's
   * @param <T> the shape of the cell's in the board
   */
  <T extends CellShape> ICoords<T> makeCoord(int coord1, int coord2);

  /**
   * Creates a board with a given side length.
   * @param sideLength the side length of the board (in # of cells)
   * @return the board
   */
  IBoard buildBoard(int sideLength);

  /**
   * Creates a model with a given side length.
   * @param sideLength the side length of the board (in # of cells)
   * @return the ReversiModel
   */
  ReversiModel buildModel(int sideLength);

  /**
   * Creates a GUI from a given read only model.
   * @param model a read only Reversi model
   * @return the RevUI
   */
  RevGUI makeGUI(ReversiROM model);

}
