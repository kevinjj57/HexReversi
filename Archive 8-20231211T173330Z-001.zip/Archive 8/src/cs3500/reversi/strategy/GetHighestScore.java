package cs3500.reversi.strategy;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.utils.ICoords;

/**
 * Represents the strategy that picks the cell that results in the most tiles flipped.
 */
public class GetHighestScore implements PlaceStrategy {
  @Override
  public List<ICoords> getValidMoves(ReversiROM model, List validMoves) {
    List<ICoords> moves = List.copyOf(validMoves);
    List<Integer> listOfInt = moves.stream().map((ICoords hc) ->
            model.valueOfMove(hc)).collect(Collectors.toList());
    List<ICoords> stratMoves;
    if (listOfInt.size() > 0) {
      Integer max = listOfInt.get(0);
      for (Integer i : listOfInt) {
        if (i > max) {
          max = i;
        }
      }
      Integer finalMax = max;
      stratMoves = moves.stream().filter((ICoords hc) ->
              model.valueOfMove(hc) == finalMax.intValue()).collect(Collectors.toList());
    } else {
      stratMoves = new ArrayList<>();
    }
    return stratMoves;
  }
}