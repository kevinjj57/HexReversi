package cs3500.reversi.strategy;

import java.util.ArrayList;
import java.util.List;

import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.utils.HexCoords;
import cs3500.reversi.utils.ICoords;

/**
 * Represents an updated version of MinMax that bases decisions of the opponents known strategies.
 */
public class MinMax implements PlaceStrategy {
  PlaceStrategy strat;

  public MinMax(PlaceStrategy strat) {
    this.strat = strat;
  }

  @Override
  public List<ICoords> getValidMoves(ReversiROM model, List validMoves) {
    List<ICoords> vm = validMoves;
    int bestScore = model.getSideLength() * model.getSideLength();
    List<ICoords> bestCoords = new ArrayList<>();
    for (ICoords coord : vm) {
      ReversiModel copy = model.copy();
      copy.placeToken(coord);
      List<HexCoords> currMoves = copy.getPossibleMoves();
      currMoves = strat.getValidMoves(copy, currMoves);
      if (currMoves.size() < bestScore) {
        bestScore = currMoves.size();
        bestCoords.clear();
        bestCoords.add(coord);
      }
      if (currMoves.size() == bestScore) {
        bestCoords.add(coord);
      }
    }
    return bestCoords;
  }
}