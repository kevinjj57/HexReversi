package cs3500.reversi.strategy;

import java.util.ArrayList;
import java.util.List;

import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.shapes.CellShape;
import cs3500.reversi.utils.ICoords;

/**
 * Represents the strategy that picks the cell if it is a corner.
 */
public class GetCorner<T extends CellShape> implements PlaceStrategy {

  @Override
  public List<ICoords> getValidMoves(ReversiROM model, List validMoves) {
    List<ICoords> corners = model.getBoard().getCorners();
    List<ICoords> ans = new ArrayList<>();
    for (ICoords coord : corners) {
      if (validMoves.contains(coord)) {
        ans.add(coord);
      }
    }
    return ans;
  }
}