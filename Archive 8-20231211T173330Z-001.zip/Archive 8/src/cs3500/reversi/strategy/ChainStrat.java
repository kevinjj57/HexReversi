package cs3500.reversi.strategy;

import java.util.List;

import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.utils.ICoords;

/**
 * Represents a strategy that allows the chaining of strategies. This is beneficial as we can
 * have the logic of picking a move from a list of strategies in the strategy directory instead
 * of the AI class, keeping similar implementations in the same place.
 */
public class ChainStrat implements PlaceStrategy {
  private PlaceStrategy[] strats;

  /**
   * Default constructor for ChainStrat.
   * @param strats variable length list of PlaceStrategies
   */
  public ChainStrat(PlaceStrategy... strats) {
    this.strats = strats;
  }

  /**
   * Gets all possible coordinates that creates Valid moves on the given ReversiModel
   * in accordance to the strategy. Listed in order from top left to bottom right.
   *
   * @param model      the model portion of Reversi
   * @param validMoves list of valid moves
   * @return the list of all possible moves given a specific strategy
   */
  @Override
  public List<ICoords> getValidMoves(ReversiROM model, List validMoves) {
    List<ICoords> currentMoves = validMoves;
    for (PlaceStrategy strat : strats) {
      List<ICoords> lohc = strat.getValidMoves(model, currentMoves);
      if (lohc.size() != 0) {
        currentMoves = lohc;
      }
    }
    return currentMoves;
  }
}
