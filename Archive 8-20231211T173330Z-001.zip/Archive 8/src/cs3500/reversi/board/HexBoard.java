package cs3500.reversi.board;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import cs3500.reversi.shapes.CellShape;
import cs3500.reversi.shapes.Hex;
import cs3500.reversi.utils.ICoords;
import cs3500.reversi.utils.TokenStatus;
import cs3500.reversi.utils.HexCoords;

/**
 * Represents the game board for a game of Reversi. This is used to hide the specific implementation
 * details of the board from the client.
 */
public class HexBoard implements IBoard<Hex> {

  private Map<Integer, Map<Integer, TokenStatus>> board;
  private final int sideLength;

  /**
   * Default constructor.
   * @param sideLength the game board's side length
   */
  public HexBoard(int sideLength) {
    this.sideLength = sideLength;
    this.board = new HashMap<>();
    int radius = sideLength - 1;
    for (int currentIndex = -1 * radius; currentIndex <= radius; currentIndex++) {
      board.put(currentIndex, makeSizedHashmap(currentIndex));
    }
  }

  /**
   * Creates a certain sized hashmap (our unique HashMap).
   *
   * @param currentIndex the current hashmap index that this map is being placed at.
   * @return a map from an r-index to a token.
   */
  private Map<Integer, TokenStatus> makeSizedHashmap(int currentIndex) {
    return makeMtMap(getStartingIndex(currentIndex), getEndingIndex(currentIndex));
  }

  /**
   * Fills a hashmap will Empty tokens at the appropriate indexes.
   *
   * @param beginIndex r-index you wish to begin the row at.
   * @param endIndex   the r-index you wish to end the row at.
   * @return the HashMap that connects these indices and their Empty tokens.
   */
  private HashMap<Integer, TokenStatus> makeMtMap(int beginIndex, int endIndex) {
    HashMap<Integer, TokenStatus> hm = new HashMap<>();
    for (int index = beginIndex; index <= endIndex; index++) {
      hm.put(index, TokenStatus.EMPTY);
    }
    return hm;
  }

  /**
   * Gets the lowest index of the other type based on the given index.
   *   ex. on a board with side length four, the lowest index for r given a q of 0, is -3.
   *       on a board with side length four, the lowest index for q given an r of -2, is -1.
   *       on a board with side length four, the lowest index for q given an r of 3, is -3.
   * @param index the index number you wish to compare to.
   * @return the minimum index.
   */
  private int getStartingIndex(int index) {
    if (index < 0) {
      return -sideLength + 1 - index;
    } else {
      return -sideLength + 1;
    }
  }

  /**
   * Gets the highest index of the other type based on the given index.
   *   ex. on a board with side length four, the highest index for r given a q of 0, is 3.
   *       on a board with side length four, the highest index for q given an r of -2, is 3.
   *       on a board with side length four, the highest index for q given an r of 3, is 0.
   * @param index the index number you wish to compare to.
   * @return the maximum index.
   */
  private int getEndingIndex(int index) {
    if (index < 0) {
      return sideLength - 1;
    } else {
      return widthOfIndex(index) - sideLength;
    }
  }

  private int widthOfIndex(int index) {
    return (2 * this.sideLength) - 1 - Math.abs(index);
  }


  /**
   * Gets the color of a piece at the given HexCoords on the Board.
   *
   * @param hc the axial coordinate of the piece you would like to get.
   * @return the Token color or Empty if the space is empty.
   * @throws IndexOutOfBoundsException if the coordinate is off the board.
   */
  @Override
  public TokenStatus getPieceAt(ICoords<Hex> hc) throws IndexOutOfBoundsException {
    return board.get(hc.getFirst()).get(hc.getSecond());
  }


  /**
   * Gets the side length of this hexagonal board.
   *
   * @return the appropriate side length.
   */
  @Override
  public int getSideLength() {
    return (board.size() + 1) / 2;
  }

  /**
   * /**
   * Adds a token of the given color to this board.
   *
   * @param hc the coordinates you wish to add the colored token at.
   * @param gc the GameColor of the token.
   * @throws IndexOutOfBoundsException if the coordinates are off the board.
   */
  @Override
  public void addToBoard(ICoords<Hex> hc, TokenStatus gc) throws IndexOutOfBoundsException {
    board.get(hc.getFirst()).put(hc.getSecond(), gc);
  }

  /**
   * Copies this board.
   *
   * @return a copy of this board.
   */
  @Override
  public IBoard copyBoard() {
    IBoard ans = new HexBoard(sideLength);
    for (Map.Entry<Integer, Map<Integer, TokenStatus>> entry : this.board.entrySet()) {
      int q = entry.getKey();
      for (Map.Entry<Integer, TokenStatus> inside : entry.getValue().entrySet()) {
        int r = inside.getKey();
        TokenStatus color = inside.getValue();
        ans.addToBoard(new HexCoords(q, r), color);
      }
    }
    return ans;
  }

  /**
   * Gets all the valid coordinates of this board.
   *
   * @return a set of all coordinates.
   */
  @Override
  public Set<ICoords<Hex>> getValidCoords() {
    Set<ICoords<Hex>> ans = new HashSet<>();
    for (Integer q : board.keySet()) {
      for (Integer r : board.get(q).keySet()) {
        ans.add(new HexCoords(q, r));
      }
    }
    return ans;
  }

  /**
   * Two boards are equal if they are the same size with the same pieces at the same
   * axial coordinates.
   *
   * @param o the object you wish to compare this with.
   * @return if the object is equivalent to this HexReversiBoard.
   */
  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (!(o instanceof IBoard)) {
      return false;
    }
    IBoard that = (IBoard) o;
    if (!(that.getValidCoords().equals(this.getValidCoords()))) {
      return false;
    }

    for (ICoords<Hex> hc : this.getValidCoords()) {
      if (that.getPieceAt(hc) != this.getPieceAt(hc)) {
        return false;
      }
    }
    return true;
  }

  @Override
  public List<ICoords<Hex>> getCorners() {
    CellShape hex = new Hex();
    List<ICoords<Hex>> ans = new ArrayList<>();
    int offset = sideLength - 1;
    for (ICoords<Hex> hc : hex.getVectors()) {
      ans.add(hex.makeCoord(hc.getFirst() * offset, hc.getSecond() * offset));
    }
    return ans;
  }

  /**
   * Overridden because {@code equals()} was also overridden.
   * @return this MyBoard's hashcode.
   */
  @Override
  public int hashCode() {
    return Objects.hash(sideLength, 5, 7, 13);
  }

}
