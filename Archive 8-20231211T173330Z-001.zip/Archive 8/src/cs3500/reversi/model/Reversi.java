package cs3500.reversi.model;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

import cs3500.reversi.board.IBoard;
import cs3500.reversi.controller.ModelFeatures;
import cs3500.reversi.controller.RevController;
import cs3500.reversi.player.Player;
import cs3500.reversi.shapes.CellShape;
import cs3500.reversi.utils.ICoords;
import cs3500.reversi.utils.TokenStatus;
import cs3500.reversi.view.FakeView;


/**
 * Represents a specific version of the game Reversi. This version of Reversi is played on a
 * Hexagonal game board. All standard rules otherwise apply. The goal of the game is to have more
 * of your color tokens than the opponents. Players take turns playing, they can either pass
 * or place a token. A valid token can be placed only when it forms a "sandwich" with another one
 * of your tokens. By doing this, it flips all the opponents tokens over to your color between
 * the sandwich.
 */
public abstract class Reversi<T extends CellShape> implements ReversiModel<T> {

  /**
   * Hexagonal Reversi Board.
   * See AxialCoords.jpeg in docs directory for coordinates.
   * The board map is q -> (r -> {@code TokenStatus})
   */
  // refer to axial coordinates jpeg
  // outer map represents q coordinate
  // inner map represents r coordinate to GameColor (White/Black)
  //INVARIANT:
  // if the absolute value of q, r, and (q + r), are all less than side length,
  // the coordinate will be on the board.
  private IBoard board;
  private final int sideLength;
  //INVARIANT: The player queue has a length of 2, and will only ever contain the two
  //IPlayers given in constructor.
  private Queue<ModelFeatures> players = new ArrayDeque<>();
  private boolean gameOver;
  private boolean previousPlayPass;
  private int whiteScore;
  private int blackScore;
  private boolean gameStarted;
  protected CellShape cb;


  /**
   * Default constructor for a game of Reversi.
   * @param sideLength the game board side length.
   */
  public Reversi(int sideLength) {
    if (illegalSideLength(sideLength)) {
      throw new IllegalArgumentException("Bad Args.");
    }
    this.sideLength = sideLength;
  }

  /**
   * Copy constructor to allow for new models to be made that do not mutate this model.
   * @param model the reversi model
   */
  public Reversi(ReversiROM model) {
    this.board = model.getBoard();
    this.sideLength = model.getSideLength();
    new RevController(this, new Player(), new FakeView());
    new RevController(this, new Player(), new FakeView());
    if (model.whoseTurn() == TokenStatus.WHITE) {
      this.nextTurn();
    }
    gameStarted = true;
    previousPlayPass = false;
    whiteScore = model.getScoreWhite();
    blackScore = model.getScoreBlack();
  }

  protected void setUpGame() {
    board = cb.buildBoard(sideLength);
    //Creates the board in accordance to the coordinate invariant.
    placeInitialTokens();
  }


  //Helper method to create invariant.
  private void addPlayers(ModelFeatures cont) {
    //players = new ArrayDeque<>();
    //players.add(TokenStatus.BLACK);
    //players.add(TokenStatus.WHITE);
    if (players.size() == 2) {
      throw new IllegalStateException("Already have two players");
    }
    players.add(cont);
    if (players.size() == 1) {
      cont.assignColor(TokenStatus.BLACK);
    } else {
      cont.assignColor(TokenStatus.WHITE);
    }
  }



  /**
   * Determines the max width a game board could be given a specific side length.
   * Can find the max number of q's in terms of r, or r in terms of q.
   *
   * @return the max cell width for a game
   */
  private int maxBoardWidth() {
    return (2 * this.sideLength) - 1;
  }

  /**
   * Returns the length of the board  at a specific q or r index. For example, at q = 0, the width
   * would be 7, as the board is 7 cells wide at q = 0.
   *
   * @param index determines the width of the given index.
   *              No matter which index you're measuring in, the max width in terms
   *              of that index will be the same.
   * @return the width.
   */
  private int widthOfIndex(int index) {
    return maxBoardWidth() - Math.abs(index);
  }

  /**
   * Places the initial tokens on the game board. Three black and three white tokens are placed
   * surrounding the center-most cell.
   * Additionally, adds the given points for the base tokens.
   * Uses putTokenHere because these are not valid player moves, and therefore placeToken
   * would throw an ISE.
   */
  protected void placeInitialTokens() {
    blackScore = 3;
    whiteScore = 3;
    TokenStatus currentColor = TokenStatus.BLACK;
    for (ICoords direction : cb.getVectors()) {
      putTokenHere(currentColor, cb.makeCoord(direction.getFirst(), direction.getSecond()));
      currentColor = getOppColor(currentColor);
    }
  }

  /**
   * Determines if an illegal side length was given. For a game of Reversi, the side length must
   * be larger than 2 for it to be a valid game.
   *
   * @param sideLength the number of cells per side
   * @return the boolean for whether a side length is legal
   */
  private boolean illegalSideLength(int sideLength) {
    return sideLength < 2;
  }

  //Relies on IPlayer invariant.

  @Override
  public void placeToken(ICoords<T> coord) {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not been started");
    }
    if (isGameOver()) {
      throw new IllegalStateException("Game over");
    }
    if (getTokenAt(coord) != TokenStatus.EMPTY) {
      throw new IllegalStateException("Token already there");
    }
    if (!legalCoords(coord)) {
      throw new IllegalArgumentException("Bad coords");
    }
    if (!legalPlacement(whoseTurn(), coord)) {
      throw new IllegalStateException("Invalid play.");
    }
    updateScore(coord);
    putTokenHere(whoseTurn(), coord);
    flipAll(coord);
    previousPlayPass = false;
    nextTurn();
  }

  @Override
  public void pass() {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not been started");
    }
    if (isGameOver()) {
      throw new IllegalStateException("Game over");
    }
    if (previousPlayPass) {
      gameOver = true;
      for (ModelFeatures f : players) {
        f.gameOver();
      }
    } else {
      previousPlayPass = true;
      nextTurn();
    }
  }

  @Override
  public void startGame() {
    if (gameStarted) {
      throw new IllegalStateException("Game already started");
    }
    if (players.size() != 2) {
      throw new IllegalStateException("Need two players");
    }
    gameStarted = true;
    nudgePlayer();
  }

  @Override
  public int valueOfMove(ICoords hc) {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not been started");
    }
    if (hc == null || !legalPlacement(whoseTurn(), hc)) {
      throw new IllegalArgumentException("Not a valid move");
    }
    return getActivatedTokens(whoseTurn(), hc).size();
  }

  @Override
  public TokenStatus whoseTurn() {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not been started");
    }
    return players.peek().getColor();
  }

  @Override
  public void addMoveListener(ModelFeatures listener) {
    addPlayers(listener);
  }

  private void updateScore(ICoords coords) {
    int scoreChange = getActivatedTokens(whoseTurn(), coords).size();
    if (whoseTurn() == TokenStatus.BLACK) {
      blackScore += scoreChange + 1;
      whiteScore -= scoreChange;
    } else {
      whiteScore += scoreChange + 1;
      blackScore -= scoreChange;
    }
  }

  private boolean legalPlacement(TokenStatus color, ICoords coord) {
    return getActivatedTokens(color, coord).size() != 0;
  }

  private void flipAll(ICoords coord) {
    List<ICoords> affected = getActivatedTokens(whoseTurn(), coord);
    for (ICoords token : affected) {
      flip(token);
    }
  }

  private List<ICoords> getActivatedTokens(TokenStatus begColor, ICoords hc) {
    List<ICoords> ans = new ArrayList<>();
    for (ICoords direction : cb.getVectors()) {
      ans.addAll(getAllInADirection(begColor, direction, hc, new ArrayList<>()));
    }
    return ans;
  }

  private List<ICoords> getAllInADirection(
          TokenStatus begColor, ICoords dir, ICoords hc, List<ICoords> ans) {
    ICoords nextCoords = cb.makeCoord(hc.getFirst() + dir.getFirst(), hc.getSecond() +
            dir.getSecond());
    if (legalCoords(nextCoords)) {
      TokenStatus nextToken = getTokenAt(nextCoords);
      if (nextToken != TokenStatus.EMPTY) {
        if (nextToken == begColor) {
          return ans;
        } else {
          ans.add(nextCoords);
          return getAllInADirection(begColor, dir, nextCoords, ans);
        }
      }
    }
    return new ArrayList<>();
  }

  //Helper method to enforce given coordinates ensure the invariant.
  private boolean legalCoords(ICoords coords) {
    return board.getValidCoords().contains(coords);
  }

  @Override
  public int getSideLength() {
    return sideLength;
  }

  @Override
  public int getScoreBlack() {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not been started");
    }
    return blackScore;
  }

  @Override
  public int getScoreWhite() {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not been started");
    }
    return whiteScore;
  }

  @Override
  public boolean isGameOver() {
    return gameOver;
  }

  @Override
  public IBoard getBoard() {
    return board.copyBoard();
  }

  @Override
  public boolean isMoveLegal(ICoords hc) {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not been started");
    }
    if (hc == null) {
      throw new IllegalArgumentException("Null Coords");
    }
    return legalCoords(hc) && getTokenAt(hc) == TokenStatus.EMPTY &&
            legalPlacement(whoseTurn(), hc);
  }
  
  /**
   * Gets the lowest index of the other type based on the given index.
   *   ex. on a board with side length four, the lowest index for r given a q of 0, is -3.
   *       on a board with side length four, the lowest index for q given an r of -2, is -1.
   *       on a board with side length four, the lowest index for q given an r of 3, is -3.
   * @param index the index number you wish to compare to.
   * @return the minimum index.
   */
  private int getStartingIndex(int index) {
    if (index < 0) {
      return -sideLength + 1 - index;
    } else {
      return -sideLength + 1;
    }
  }

  /**
   * Gets the highest index of the other type based on the given index.
   *   ex. on a board with side length four, the highest index for r given a q of 0, is 3.
   *       on a board with side length four, the highest index for q given an r of -2, is 3.
   *       on a board with side length four, the highest index for q given an r of 3, is 0.
   * @param index the index number you wish to compare to.
   * @return the maximum index.
   */
  private int getEndingIndex(int index) {
    if (index < 0) {
      return sideLength - 1;
    } else {
      return widthOfIndex(index) - sideLength;
    }
  }

  /**
   * Places a token at the given coordinates without checking if it is a legal move.
   *
   * @param coord a cell's coordinate.
   */
  protected void putTokenHere(TokenStatus color, ICoords coord) {
    if (getTokenAt(coord) != TokenStatus.EMPTY) {
      throw new IllegalStateException("Token already there");
    }
    if (!legalCoords(coord) || color == TokenStatus.EMPTY) {
      throw new IllegalArgumentException("Bad args");
    }
    board.addToBoard(coord, color);
  }

  /**
   * Same as getTokenAt, but this is a private method
   * that returns the actual token at that location.
   *
   * @param coords a cell's coordinate
   * @return the token at a specific cell
   */
  public TokenStatus getTokenAt(ICoords coords) {
    if (coords == null || !legalCoords(coords)) {
      throw new IllegalArgumentException("Bad coords");
    }
    return board.getPieceAt(coords);
  }

  private void flip(ICoords hc) {
    if (getTokenAt(hc) == TokenStatus.EMPTY) {
      throw new IllegalStateException("Token not there");
    }
    TokenStatus color = getOppColor(getTokenAt(hc));
    board.addToBoard(hc, color);
  }

  private TokenStatus getOppColor(TokenStatus color) {
    if (color.equals(TokenStatus.BLACK)) {
      return TokenStatus.WHITE;
    } else {
      return TokenStatus.BLACK;
    }
  }

  //Upholds player number invariant.
  private void nextTurn() {
    players.peek().refreshAll();
    this.players.add(this.players.remove());
    players.peek().refreshAll();
    nudgePlayer();
  }


  /**
   * Lets the current player know its their turn.
   */
  void nudgePlayer() {
    players.peek().yourTurn();
  }

  /**
   * Lists all possible moves in order from top left to bottom right.
   * @return the wished for list.
   */
  @Override
  public List<ICoords<T>> getPossibleMoves() {
    if (!gameStarted) {
      throw new IllegalStateException("Game has not been started");
    }
    List<ICoords<T>> ans = new ArrayList<>();
    for (Object coord : this.board.getValidCoords()) {
      ICoords c = (ICoords) coord;
      if (isMoveLegal(c)) {
        ans.add(c);
      }
    }
    return ans;
  }
}
