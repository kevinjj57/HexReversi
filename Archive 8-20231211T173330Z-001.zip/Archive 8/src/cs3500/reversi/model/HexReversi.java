package cs3500.reversi.model;


import cs3500.reversi.shapes.CellShape;
import cs3500.reversi.shapes.Hex;

/**
 * Specific model representation for a game of Hex Reversi.
 */
public class HexReversi extends Reversi<Hex> {

  /**
   * Default constructor for a game of Reversi.
   *
   * @param sideLength the game board side length.
   */
  public HexReversi(int sideLength) {
    super(sideLength);
    cb = new Hex();
    setUpGame();
  }

  public HexReversi(ReversiROM model) {
    super(model);
  }

  @Override
  public CellShape getShape() {
    return cb;
  }

  @Override
  public ReversiModel copy() {
    return new HexReversi(this);
  }
}
