package cs3500.reversi.view;

import java.awt.Point;
import java.awt.Polygon;

import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.shapes.Hex;
import cs3500.reversi.utils.ICoords;

/**
 * Represents the GUI for a game of Hex Reversi.
 */
public class HexGUI extends ReversiGraphicsView<Hex> {


  /**
   * Default constructor for our graphical view.
   *
   * @param width  width of the screen
   * @param height height of the screen
   * @param model  the ROM that you want this view to read the board from.
   */
  public HexGUI(int width, int height, ReversiROM model) {
    super(width, height, model);
    shapeSL = getMiniHexSL();
  }


  protected int getMiniHexSL() {
    return Math.round(getBoardHeight() / (6 * model.getSideLength()));
  }

  @Override
  protected Polygon makeShape(Point p) {
    int apothem = getMiniApothem();
    int sideL = getMiniHexSL();
    int cX = p.x;
    int cY = p.y;
    int[] xS = {cX, cX + apothem, cX + apothem, cX, cX - apothem, cX - apothem};
    int[] yS = {cY + 2 * sideL, cY + sideL, cY - sideL, cY - 2 * sideL, cY - sideL, cY + sideL};
    return new Polygon(xS, yS, 6);
  }

  @Override
  public Point xyOffset(ICoords<Hex> hc) {
    Point ans = new Point(0, 0);
    ans.x += hc.getFirst() * 2 * getMiniApothem();
    ans.x += hc.getSecond() * getMiniApothem();
    ans.y += hc.getSecond() * 3 * getMiniHexSL();

    return ans;
  }
}
