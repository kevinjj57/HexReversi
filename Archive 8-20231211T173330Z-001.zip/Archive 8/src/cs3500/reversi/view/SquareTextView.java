package cs3500.reversi.view;

import java.io.IOException;

import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.utils.SquareCoords;
import cs3500.reversi.utils.TokenStatus;

/**
 * A textual view for a square board.
 */
public class SquareTextView implements TextView {

  private ReversiROM model;

  /**
   * Default constructor for textual view Reversi.
   */
  public SquareTextView(ReversiROM model) {
    this.model = model;
  }

  @Override
  public String toString() {
    Appendable ans = new StringBuffer(" ");
    int modelSideLength = model.getSideLength();
    for (int y = modelSideLength; y > 0; y--) {
      addStringTo(ans, "\n ");
      for (int x = 0; x < modelSideLength; x++) {
        String s = colorToString(model.getTokenAt(new SquareCoords(x, y)));
        addStringTo(ans, s + " ");
      }
    }
    return ans.toString();
  }

  /**
   * They way you'd like each color represented as a String.
   *
   * @param gc the color.
   * @return the given representation.
   */
  private String colorToString(TokenStatus gc) {
    switch (gc) {
      case BLACK:
        return "X";
      case WHITE:
        return "O";
      case EMPTY:
        return "_";
      default:
        throw new IllegalArgumentException("Not a good color enum.");
    }
  }


  private void addStringTo(Appendable app, String s) {
    try {
      app.append(s + " ");
    } catch (IOException e) {
      throw new IllegalArgumentException("bad appendable");
    }
  }
}
