package cs3500.reversi.view;

import java.awt.Graphics2D;
import java.awt.Polygon;

import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.utils.ICoords;

/**
 * Represents the style a cell will be selected in.
 */
public interface CellSelected {

  /**
   * Displays a clicked cell.
   * @param g2d the graphics object
   * @param p the shape
   * @param model the read only model
   * @param coord the specific coordinate
   */
  void displayCell(Graphics2D g2d, Polygon p, ReversiROM model, ICoords coord);
}
