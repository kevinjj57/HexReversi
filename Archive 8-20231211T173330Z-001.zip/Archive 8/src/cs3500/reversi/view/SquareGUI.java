package cs3500.reversi.view;

import java.awt.Point;
import java.awt.Polygon;

import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.shapes.Square;
import cs3500.reversi.utils.ICoords;

/**
 * Represents a GUI for a game of Square Reversi.
 */
public class SquareGUI extends ReversiGraphicsView<Square> {

  /**
   * Default constructor for our graphical view.
   *
   * @param width  width of the screen
   * @param height height of the screen
   * @param model  the ROM that you want this view to read the board from.
   */
  public SquareGUI(int width, int height, ReversiROM model) {
    super(width, height, model);
    shapeSL = (int) Math.round(getMiniApothem() * 1.25);
  }



  @Override
  protected Polygon makeShape(Point p) {
    int[] xs = {p.x + shapeSL, p.x - shapeSL, p.x - shapeSL, p.x + shapeSL};
    int[] ys = {p.y + shapeSL, p.y + shapeSL, p.y - shapeSL, p.y - shapeSL};
    return new Polygon(xs, ys, 4);
  }

  //fix this
  @Override
  protected Point xyOffset(ICoords coord) {
    Point ans = new Point(0, 0);
    ans.x += (-model.getSideLength() * shapeSL) + coord.getFirst() * shapeSL * 2;
    ans.y += (-model.getSideLength() * shapeSL) + coord.getSecond() * shapeSL * 2;
    return ans;
  }
}
