package cs3500.reversi.view;

/**
 * Represents the simple textual view for the game Reversi. Outputs the game state as a string.
 * A textual view displays black tokens as X, white tokens as O, and an empty cell as _.
 */
public interface TextView {

  /**
   * A string display of the CURRENT state of the Reversi Model.
   * @return a single string showing the board state.
   */
  String toString();
}
