package cs3500.reversi.view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Arrays;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import cs3500.reversi.board.IBoard;
import cs3500.reversi.controller.PlayerFeatures;
import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.shapes.CellShape;
import cs3500.reversi.utils.ICoords;
import cs3500.reversi.utils.TokenStatus;

/**
 * Represents our graphical view for a game of Reversi using Java Swing.
 *
 * <p>If you give this view a ReadOnlyModel, and assign a PlayerFeatures interface as a listener
 * this view will display properly.
 *
 * <p>Click on tiles to select them.
 * Reclick on the selected tile to deselect.
 * Click on a new tile to deselect the current one and select the new one.
 * Click enter to place a token on that selected tile.
 * Enter P to pass.
 */
public abstract class ReversiGraphicsView<T extends CellShape> extends JFrame implements RevGUI {

  private MyHexPanel panel;
  private PlayerFeatures feat;
  protected ReversiROM model;
  protected Polygon polygon;
  protected int shapeSL;
  private boolean scoreHint;

  /**
   * Default constructor for our graphical view.
   *
   * @param width      width of the screen
   * @param height     height of the screen
   * @param model      the ROM that you want this view to read the board from.
   */
  public ReversiGraphicsView(int width, int height, ReversiROM model) {
    super();
    this.model = model;
    setTitle("Reversi");
    setSize(width, height);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    panel = new MyHexPanel();
    this.setFocusable(true);
    JScrollPane scrolls = new JScrollPane(panel);
    this.add(scrolls);
    setVisible(true); // should set visible with a makeVisible method
  }

  @Override
  public void render() {
    panel.updateUI();
  }

  /**
   * Sets the given PlayerFeatures interface as a listener for high-level events executed by
   * this view. Will call methods on this features interface when propted.
   * @param feat the interface you want to be notified when moves are made.
   */
  @Override
  public void setCommandListener(PlayerFeatures feat) {
    this.feat = feat;
  }

  /**
   * Displays the given message to the player on the board.
   * @param message the message you wish to display.
   */
  @Override
  public void showMessage(String message) {
    JOptionPane.showMessageDialog(panel, message);
  }

  /**
   * Sets this panel as the focus of key and mouse commands. Should be called when the
   * listening controller's turn begins.
   */
  @Override
  public void setFocus() {
    panel.requestFocus();
  }

  /**
   * Removes this panel as the focus of key and mouse commands. Should be called when the
   * listening controller's turn ends.
   */
  @Override
  public void removeFocus() {
    panel.transferFocus();
  }

  private Point getOffsetPosn() {
    return this.getLocation();
  }


  protected abstract Polygon makeShape(Point p);

  protected abstract Point xyOffset(ICoords<T> coord);

  protected int getBoardHeight() {
    return panel.getHeight();
  }

  @Override
  public void displayHints() {
    panel.hints = true;
  }



  private class MyHexPanel extends JPanel {
    private ICoords<T> hcc;
    private Point pc;
    boolean hints = false;

    MyHexPanel() {
      super();
      setBackground(Color.GRAY);
      addMouseListener(new RevMouseListener());
      addKeyListener(new RevKeyListener());
      addFocusListener(new RevFocusListener());
    }

    private class RevFocusListener extends FocusAdapter {
      /**
       * Invoked when a component gains the keyboard focus.
       *
       * @param e the focus event
       */
      @Override
      public void focusGained(FocusEvent e) {
        super.focusGained(e);
      }

      /**
       * Invoked when a component loses the keyboard focus.
       *
       * @param e the focus event
       */
      @Override
      public void focusLost(FocusEvent e) {
        super.focusLost(e);
      }
    }

    private class RevKeyListener extends KeyAdapter {

      @Override
      public void keyPressed(KeyEvent e) {
        if (inFocus()) {
          int keyCode = e.getKeyCode();
          switch (keyCode) {
            case KeyEvent.VK_P: // pass
              resetClicked();
              feat.pass();
              break;
            case KeyEvent.VK_ENTER: // place
              if (hcc == null) {
                showMessage("Must select cs3500.reversi.shapes.Hex to play");
              } else {
                ICoords<T> coords = hcc;
                resetClicked();
                feat.placeToken(coords);
              }
              break;
            case KeyEvent.VK_H: // hints on/off
              hints = !hints;
              render();
              break;
            default:
              throw new IllegalArgumentException();
          }
        }
      }
    }

    private class RevMouseListener extends MouseAdapter {

      @Override
      public void mouseClicked(MouseEvent e) {
        if (inFocus()) {
          Point clicked = e.getLocationOnScreen();
          clicked.x = clicked.x - getOffsetPosn().x;
          clicked.y = clicked.y - getOffsetPosn().y;
          clicked.x -= getWidth() / 2;
          clicked.y -= getHeight() / 2;
          pc = clicked;
          render();
        }
      }
    }

    private boolean inFocus() {
      return this.hasFocus();
    }

    private void resetClicked() {
      hcc = null;
    }


    /**
     * Paints the board as give by the ReadOnlyModel based on an axial coordinate system.
     * @param g the <code>Graphics</code> object to protect
     */
    @Override
    public void paintComponent(Graphics g) {
      super.paintComponent(g);
      Graphics2D g2d = (Graphics2D) g;
      //Set origin to the center of the screen.
      g2d.translate(this.getWidth() / 2, this.getHeight() / 2);
      g2d.scale(1, 1);
      IBoard board = model.getBoard();
      int sideLength = model.getSideLength();
      int boardSize = panel.getHeight();
      int hexSize = Math.round(boardSize / (3 * sideLength));
      int apothem = Math.toIntExact(Math.round(Math.sqrt(3)) * hexSize);
      drawBoard(g2d, board);
    }

    private void drawBoard(Graphics2D g2d, IBoard board) {
      for (Object c : board.getValidCoords()) {
        ICoords<T> coord = (ICoords<T>) c;
        Point point = xyOffset(coord);
        Polygon p = makeShape(xyOffset(coord));
        g2d.setColor(Color.BLACK);
        g2d.drawPolygon(p);
        //If you clicked on this hexagon.
        if (pc != null && p.contains(pc)) {
          //if you click the same tile as before it deselects.
          if (hcc != null && hcc.getFirst() == coord.getFirst()
                  && hcc.getSecond() == coord.getSecond()) {
            pc = null;
            resetClicked();
          }
          //If you click on a new one, it deselects the old one and selects the new one.
          else {
            pc = null;
            hcc = coord;
            g2d.setColor(Color.CYAN);
            g2d.fill(p);
            if (hints) {
              g2d.setColor(Color.BLACK);
              String val =
                      model.isMoveLegal(coord) ? String.valueOf(model.valueOfMove(coord)) : "0";
              g2d.drawString(val, avgVal(p.xpoints), avgVal(p.ypoints));
            }
          }
        }
        //Places token at center of hex.
        g2d.setColor(getColor(board.getPieceAt(coord)));
        g2d.fillOval(point.x - shapeSL / 2, point.y - shapeSL / 2, shapeSL, shapeSL);
      }
    }

    private Color getColor(TokenStatus color) {
      switch (color) {
        case BLACK:
          return Color.BLACK;
        case WHITE:
          return Color.WHITE;
        case EMPTY:
          return new Color(0, 0, 0, 0);
        default:
          throw new IllegalArgumentException("Bad Color");
      }
    }
  }

  protected int getMiniApothem() {
    return Math.toIntExact(panel.getWidth() /
            (2 * (2 * model.getSideLength() - 1)));
  }

  private static int avgVal(int... ints) {
    return (Arrays.stream(ints).min().getAsInt() + Arrays.stream(ints).max().getAsInt()) / 2;
  }
}
