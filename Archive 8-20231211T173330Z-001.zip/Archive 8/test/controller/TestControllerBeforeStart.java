package controller;

import org.junit.Before;
import org.junit.Test;

import cs3500.reversi.controller.IController;
import cs3500.reversi.controller.RevController;
import cs3500.reversi.utils.HexCoords;
import cs3500.reversi.utils.TokenStatus;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Class for testing what the controller does before the game is started.
 */
public abstract class TestControllerBeforeStart {
  protected ModelForTesting mockDeli;
  protected IController cont0;
  protected IController cont1;
  protected PlayerForTesting p0;
  protected PlayerForTesting p1;
  protected ViewForTesting view0;
  protected ViewForTesting view1;

  @Before
  public void addStuff() {
    p0 = new PlayerForTesting();
    p1 = new PlayerForTesting();
    view0 = new ViewForTesting();
    view1 = new ViewForTesting();
    cont0 = new RevController(mockDeli, p0, view0);
    cont1 = new RevController(mockDeli, p1, view1);
  }

  @Test
  public void testModelListener() {
    assertTrue(mockDeli.listeners.contains(cont0));
    assertTrue(mockDeli.listeners.contains(cont1));
    assertEquals(2, mockDeli.listeners.size());
  }

  @Test
  public void testViewListener() {
    assertEquals(cont0, view0.contListener);
    assertEquals(cont1, view1.contListener);
  }

  @Test
  public void testPlayerAssignment() {
    assertEquals(cont0, p0.feat);
    assertEquals(cont1, p1.feat);
  }

  @Test
  public void testPassWontWork() {
    assertEquals(mockDeli.transcript.toString(), "");
    cont0.pass();
    assertEquals(mockDeli.transcript.toString(), "");
  }

  @Test
  public void testPlaceTokenWontWork() {
    assertEquals(mockDeli.transcript.toString(), "");
    HexCoords hc = new HexCoords(1, -2);
    cont0.placeToken(hc);
    assertEquals(mockDeli.transcript.toString(), "");
    assertEquals(mockDeli.getTokenAt(hc), TokenStatus.EMPTY);
  }
}