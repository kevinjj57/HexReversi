package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import cs3500.reversi.board.IBoard;
import cs3500.reversi.controller.ModelFeatures;
import cs3500.reversi.model.Reversi;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.shapes.CellShape;
import cs3500.reversi.utils.ICoords;
import cs3500.reversi.utils.TokenStatus;

/**
 * Represents a mock model for testing purposes.
 */
public class ModelForTesting<T extends CellShape> implements ReversiModel<T> {

  public Appendable transcript;
  private final ReversiModel delegate;
  List<ModelFeatures> listeners;

  /**
   * Model for controller testing.
   * @param sideLength the side length.
   * @param model the model.
   * @param <T> the model type.
   */
  public <T extends Reversi> ModelForTesting(int sideLength, T model) {
    delegate = model;
    transcript = new StringBuilder();
    listeners = new ArrayList<>();
  }

  /**
   * Placing a token on the board.
   *
   * @param coord the coordinates you wish to place this token.
   * @throws IllegalArgumentException if the coords are off the board.
   * @throws IllegalStateException    if the coordinates already have a token at that location.
   */
  @Override
  public void placeToken(ICoords<T> coord) {
    delegate.placeToken(coord);
    append("Placed Token (First, Second): " + coord.getFirst() + ", " + coord.getSecond());
  }

  /**
   * Skips the current player's turn. When two players pass back to back, the game is over.
   */
  @Override
  public void pass() {
    delegate.pass();
    append("Passed");
  }

  @Override
  public void startGame() {
    delegate.startGame();
    append("Game Started");
  }

  /**
   * Returns a copy of the token at the coordinates.
   *
   * @param c the coordinates you wish to get the token from.
   * @return the copy.
   */
  @Override
  public TokenStatus getTokenAt(ICoords<T> c) {
    return delegate.getTokenAt(c);
  }

  /**
   * Gets the side length of the game board. This is the number of cells wide/tall the hexagon
   * board is.
   *
   * @return side length
   */
  @Override
  public int getSideLength() {
    return delegate.getSideLength();
  }

  /**
   * Gets the current score for black.
   *
   * @return black's score
   */
  @Override
  public int getScoreBlack() {
    return delegate.getScoreBlack();
  }

  /**
   * Gets the current score for white.
   *
   * @return white's score
   */
  @Override
  public int getScoreWhite() {
    return delegate.getScoreWhite();
  }

  /**
   * Determines if the game is over. A game of Reversi ends when two players pass back to back or
   * the board is full.
   *
   * @return if the game is over
   */
  @Override
  public boolean isGameOver() {
    return delegate.isGameOver();
  }

  /**
   * Gets a COPY of the board that this game is being played on.
   *
   * @return the copied board.
   */
  @Override
  public IBoard getBoard() {
    return delegate.getBoard();
  }

  /**
   * States whether a move by the current player at these hexCoords is legal.
   *
   * @param hc the coordinates you wish to play at.
   * @return boolean stating whether the move was true.
   * @throws IllegalArgumentException if HexCoords are null.
   */
  @Override
  public boolean isMoveLegal(ICoords<T> hc) throws IllegalArgumentException {
    return delegate.isMoveLegal(hc);
  }

  /**
   * Lists all possible moves in order from top left to bottom right.
   * if the returned list is empty, there are no possible moves for the player whose turn it is.
   *
   * @return the wished for list.
   */
  @Override
  public List<ICoords<T>> getPossibleMoves() {
    return delegate.getPossibleMoves();
  }

  /**
   * States the value of a given move.
   *
   * @param hc the coordinates you wish to play at.
   * @return the value of the move.
   * @throws IllegalArgumentException if the move is not legal or HexCoords are null.
   */
  @Override
  public int valueOfMove(ICoords<T> hc) throws IllegalArgumentException {
    return delegate.valueOfMove(hc);
  }

  /**
   * Shows what color's turn it is currently.
   *
   * @return the color of whose turn it is.
   */
  @Override
  public TokenStatus whoseTurn() {
    return delegate.whoseTurn();
  }

  @Override
  public void addMoveListener(ModelFeatures cont) {
    delegate.addMoveListener(cont);
    listeners.add(cont);
  }

  @Override
  public CellShape getShape() {
    return delegate.getShape();
  }

  private void append(CharSequence s) {
    try {
      transcript.append(s + "\n");
    } catch (IOException e) {
      throw new IllegalStateException();
    }
  }

  public ReversiModel copy() {
    return delegate.copy();
  }
}
