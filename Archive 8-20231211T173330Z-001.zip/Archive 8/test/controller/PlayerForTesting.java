package controller;



import cs3500.reversi.controller.PlayerFeatures;
import cs3500.reversi.player.IPlayer;
import cs3500.reversi.player.Player;
import cs3500.reversi.utils.ICoords;
import cs3500.reversi.utils.TokenStatus;

/**
 * Represents a mock player for testing purposes.
 */
public class PlayerForTesting implements IPlayer {
  IPlayer deligate = new Player();
  PlayerFeatures feat;


  @Override
  public TokenStatus getColor() {
    return deligate.getColor();
  }

  @Override
  public void assignColor(TokenStatus gc) {
    deligate.assignColor(gc);
  }

  @Override
  public void assignController(PlayerFeatures feat) {
    this.feat = feat;
    deligate.assignController(feat);
  }

  @Override
  public void placeToken(ICoords coord) {
    deligate.placeToken(coord);
  }

  @Override
  public void pass() {
    deligate.pass();
  }

  @Override
  public void yourTurn() {
    deligate.yourTurn();
  }
}
