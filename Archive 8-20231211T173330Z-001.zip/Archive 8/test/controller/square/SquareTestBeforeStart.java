package controller.square;

import controller.ModelForTesting;
import controller.TestControllerBeforeStart;
import cs3500.reversi.model.HexReversi;

/**
 * Testing for a squarecontroller before start.
 */
public class SquareTestBeforeStart extends TestControllerBeforeStart {

  public SquareTestBeforeStart() {
    super();
    mockDeli = new ModelForTesting(4, new HexReversi(4));
  }
}
