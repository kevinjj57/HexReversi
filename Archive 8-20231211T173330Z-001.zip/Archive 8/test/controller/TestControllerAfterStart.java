package controller;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

/**
 * Testing class for the controller's behaviors after the game has been started.
 */
public abstract class TestControllerAfterStart {

  protected ModelForTesting mockDeli;
  protected ControllerForTesting cont0;
  protected ControllerForTesting cont1;
  protected PlayerForTesting p0;
  protected PlayerForTesting p1;
  protected ViewForTesting view0;
  protected ViewForTesting view1;

  @Before
  public void addStuff() {
    p0 = new PlayerForTesting();
    p1 = new PlayerForTesting();
    view0 = new ViewForTesting();
    view1 = new ViewForTesting();
    cont0 = new ControllerForTesting(mockDeli, p0, p0.deligate, view0);
    cont1 = new ControllerForTesting(mockDeli, p1, p1.deligate, view1);
    mockDeli.startGame();
  }


  @Test
  public void testPlayerActivatesContPass() {
    assertEquals("", cont0.app.toString());
    p0.pass();
    assertTrue(cont0.app.toString().contains("Given Move: Pass"));
  }


  @Test
  public void testPlayerCantPassIfNotTurn() {
    assertNotEquals(p1.getColor(), mockDeli.whoseTurn());
    p1.pass();
    assertNotEquals(p1.getColor(), mockDeli.whoseTurn());
  }

  @Test
  public void testViewListener() {
    assertEquals(cont0.cont, view0.contListener);
    assertEquals(cont1.cont, view1.contListener);
  }

  @Test
  public void testViewToContFeaturesPass() {
    assertEquals(cont0.getColor(), mockDeli.whoseTurn());
    cont0.pass();
    assertNotEquals(cont0.getColor(), mockDeli.whoseTurn());
  }

  @Test
  public void testModelToContFeaturesYT() {
    assertEquals("", cont1.app.toString());
    cont1.yourTurn();
    assertTrue(cont1.app.toString().contains("Given Move: YourTurn"));
  }

  @Test
  public void testModelToContFeaturesGO() {
    assertEquals("", cont0.app.toString());
    cont0.gameOver();
    assertTrue(cont0.app.toString().contains("Given Move: GameOver"));
  }

  @Test
  public void testGameOverDisplaysTie() {
    assertFalse(view0.app.toString().contains("Tie!"));
    cont0.gameOver();
    assertTrue(view0.app.toString().contains("Tie!"));
  }


  @Test
  public void testViewDisplaysScore() {
    assertFalse(view0.app.toString().contains("Black: 3."));
    assertFalse(view0.app.toString().contains("White: 3."));
    cont0.gameOver();
    assertTrue(view0.app.toString().contains("Black: 3."));
    assertTrue(view0.app.toString().contains("White: 3."));
  }

  @Test
  public void testBothViewsDisplayGameOver() {
    assertFalse(view0.app.toString().contains("Message Displayed: Tie! Black: 3. White: 3."));
    assertFalse(view1.app.toString().contains("Message Displayed: Tie! Black: 3. White: 3."));
    cont0.pass();
    cont1.pass();
    assertTrue(view0.app.toString().contains("Message Displayed: Tie! Black: 3. White: 3."));
    assertTrue(view1.app.toString().contains("Message Displayed: Tie! Black: 3. White: 3."));
  }
}