package controller.hex;

import controller.ModelForTesting;
import controller.TestControllerBeforeStart;
import cs3500.reversi.model.HexReversi;

/**
 * Testing for a hexcontroller before start.
 */
public class HexTestBeforeStart extends TestControllerBeforeStart {

  public HexTestBeforeStart() {
    super();
    mockDeli = new ModelForTesting(4, new HexReversi(4));
  }
}
