package controller;

import java.io.IOException;

import cs3500.reversi.controller.IController;
import cs3500.reversi.controller.RevController;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.player.IPlayer;
import cs3500.reversi.utils.ICoords;
import cs3500.reversi.utils.TokenStatus;
import cs3500.reversi.view.RevGUI;

/**
 * Represents a mock controller for testing purposes.
 */
public class ControllerForTesting implements IController {
  public IController cont;
  public Appendable app = new StringBuilder();
  private IPlayer player;
  private ReversiModel model;

  ControllerForTesting(ReversiModel model, IPlayer mockPlayer, IPlayer deliPlayer, RevGUI view) {
    cont = new RevController(model, deliPlayer, view);
    this.player = mockPlayer;
    this.player.assignController(this);
    this.model = model;
  }

  ControllerForTesting(ReversiModel model, IPlayer player, RevGUI view) {
    cont = new RevController(model, player, view);
    this.player = player;
    this.player.assignController(this);
    this.model = model;
  }

  /**
   * Getting a readOnly version of the model that this controller is playing on.
   *
   * @return the model in the identity of its readOnly interface so it is not to be mutated.
   */
  @Override
  public ReversiROM getROM() {
    return cont.getROM();
  }


  @Override
  public void assignColor(TokenStatus color) {
    if (color == TokenStatus.EMPTY) {
      throw new IllegalArgumentException();
    }
    cont.assignColor(color);
  }

  @Override
  public TokenStatus getColor() {
    return cont.getColor();
  }

  @Override
  public void yourTurn() {
    append("Given Move: YourTurn");
    cont.yourTurn();
  }

  @Override
  public void refreshAll() {
    cont.refreshAll();
  }

  @Override
  public void gameOver() {
    append("Given Move: GameOver");
    cont.gameOver();
  }

  private void append(String s) {
    try {
      app.append(s + "\n");
    } catch (IOException e) {
      throw new IllegalStateException();
    }
  }

  @Override
  public void pass() {
    append("Given Move: Pass");
    cont.pass();
  }

  @Override
  public void placeToken(ICoords hc) {
    append("Given Move: PlaceToken at (" + hc.getFirst() + "," + hc.getSecond() + ")");
    cont.placeToken(hc);
  }
}
