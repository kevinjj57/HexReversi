package strats;

import java.io.IOException;
import java.util.List;

import cs3500.reversi.controller.IController;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.player.IPlayer;
import cs3500.reversi.utils.HexCoords;
import cs3500.reversi.utils.ICoords;
import cs3500.reversi.utils.TokenStatus;

/**
 * Bogus controller made explicitly for testing strategies.
 */
public class ControllerForStratTests implements IController {

  IPlayer player;
  TokenStatus color;
  Appendable app = new StringBuilder();
  List<HexCoords> validMoves;
  ReversiModel model;

  ControllerForStratTests(ReversiModel model, IPlayer player) {
    model.addMoveListener(this);
    player.assignController(this);
    this.player = player;
    this.model = model;
  }

  /**
   * Ends the game. Displays the message for the end of the game, either a tie or a black or
   * white win.
   */
  @Override
  public void gameOver() {
    //Purposefully left blank.
  }

  /**
   * Set's the player to be the current turn.
   */
  @Override
  public void yourTurn() {
    validMoves = model.getPossibleMoves();
    player.yourTurn();
  }

  /**
   * Updates all objects that are listening through updates to this model through the controller.
   */
  @Override
  public void refreshAll() {
    //Purposefully left blank.
  }

  @Override
  public void assignColor(TokenStatus color) {
    if (this.color != null) {
      throw new IllegalStateException("Color already assigned");
    }
    if (color == TokenStatus.EMPTY) {
      throw new IllegalArgumentException();
    }
    this.color = color;
  }

  @Override
  public TokenStatus getColor() {
    if (this.color == null) {
      throw new IllegalStateException("Color not yet assigned");
    }
    return this.color;
  }

  /**
   * Passes the current player's turn.
   */
  @Override
  public void pass() {
    append("Given: Pass");
  }

  /**
   * Places the current's player token color at the given hexcoord.
   *
   * @param hc a cell's hex coordinate
   */
  @Override
  public void placeToken(ICoords hc) {
    append("Given: PlaceToken at (" + hc.getFirst() + "," + hc.getSecond() + ")");
  }

  /**
   * Gets the read only model so that the player can observe the model.
   *
   * @return the read only model
   */
  @Override
  public ReversiROM getROM() {
    return null;
  }

  private void append(String s) {
    try {
      app.append(s + "\n");
    } catch (IOException e) {
      throw new IllegalStateException();
    }
  }
}
