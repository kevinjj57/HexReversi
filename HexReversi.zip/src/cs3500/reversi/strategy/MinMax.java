package cs3500.reversi.strategy;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import cs3500.reversi.model.HexCoords;
import cs3500.reversi.model.Reversi;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.model.ReversiROM;

/**
 * Represents a version of MinMax that finds the best move that minimizes an opponents best move.
 */
public class MinMax implements PlaceStrategy {
  @Override
  public List<HexCoords> getValidMoves(ReversiROM model, List<HexCoords> validMoves) {
    int bestScore = model.getSideLength() * model.getSideLength();
    List<HexCoords> bestCoords = new ArrayList<>();
    for (HexCoords coord : validMoves) {
      ReversiModel copy = new Reversi(model);
      copy.placeToken(coord);
      List<HexCoords> currMoves = copy.getPossibleMoves();
      if (currMoves.size() == 0) {
        if (bestScore == 0) {
          bestCoords.add(coord);
        } else {
          bestCoords = new ArrayList<>();
          bestCoords.add(coord);
          bestScore = 0;
        }
      } else {
        Stream<Integer> ints = currMoves.stream().map(hc -> copy.valueOfMove(hc));
        Integer max = ints.max(Integer::compare).get();
        if (max == bestScore) {
          bestCoords.add(coord);
        }
        if (max < bestScore) {
          bestScore = max;
          bestCoords = new ArrayList<>();
          bestCoords.add(coord);
        }
      }
    }
    return bestCoords;
  }
}


