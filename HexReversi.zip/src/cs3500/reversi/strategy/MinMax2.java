package cs3500.reversi.strategy;

import java.util.ArrayList;
import java.util.List;

import cs3500.reversi.model.HexCoords;
import cs3500.reversi.model.Reversi;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.model.ReversiROM;

/**
 * Represents an updated version of MinMax that bases decisions of the opponents known strategies.
 */
public class MinMax2 implements PlaceStrategy {
  PlaceStrategy strat;

  public MinMax2(PlaceStrategy strat) {
    this.strat = strat;
  }

  @Override
  public List<HexCoords> getValidMoves(ReversiROM model, List<HexCoords> validMoves) {
    int bestScore = model.getSideLength() * model.getSideLength();
    List<HexCoords> bestCoords = new ArrayList<>();
    for (HexCoords coord : validMoves) {
      ReversiModel copy = new Reversi(model);
      copy.placeToken(coord);
      List<HexCoords> currMoves = copy.getPossibleMoves();
      currMoves = strat.getValidMoves(model, currMoves);
      if (currMoves.size() < bestScore) {
        bestScore = currMoves.size();
        bestCoords.clear();
        bestCoords.add(coord);
      }
      if (currMoves.size() == bestScore) {
        bestCoords.add(coord);
      }
    }
    return bestCoords;
  }
}