package cs3500.reversi.strategy;

import java.util.ArrayList;
import java.util.List;

import cs3500.reversi.model.HexCoords;
import cs3500.reversi.model.HexVectors;
import cs3500.reversi.model.ReversiROM;

/**
 * Represents the strategy that avoids the cells next to a corner.
 */
public class AvoidNextToCorner implements PlaceStrategy {

  @Override
  public List<HexCoords> getValidMoves(ReversiROM model, List<HexCoords> validMoves) {
    List<HexCoords> allCorners = new ArrayList<>();
    int cornerIndex = model.getSideLength() - 1;
    for (HexVectors vec : HexVectors.values()) {
      allCorners.add(new HexCoords(vec.qChange * cornerIndex, vec.rChange * cornerIndex));
    }
    List<HexCoords> stratMoves = new ArrayList<>();
    for (HexCoords hc : allCorners) {
      for (HexVectors vec : HexVectors.values()) {
        HexCoords nextMove = new HexCoords(hc.q + vec.qChange, hc.r + vec.rChange);
        if (model.isMoveLegal(nextMove)) {
          stratMoves.add(nextMove);
        }
      }
    }
    return stratMoves;
  }
}
