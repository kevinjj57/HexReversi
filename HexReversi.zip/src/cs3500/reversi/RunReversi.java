package cs3500.reversi;

import cs3500.reversi.controller.IController;
import cs3500.reversi.controller.OutlineController;
import cs3500.reversi.model.Reversi;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.player.IPlayer;
import cs3500.reversi.player.Player;
import cs3500.reversi.view.GUI;
import cs3500.reversi.view.ReversiGraphicsView;

/**
 * The actual runnable class of reversi.
 */
public final class RunReversi {
  /**
   * The method that allows you to run Reversi.
   * @param args does not do anything at the moment.
   */
  public static void main(String[] args) {
    ReversiModel model = new Reversi(7);
    IPlayer p1 = new Player();
    IPlayer p2 = new Player();
    IController controller = new OutlineController(model, p1, p2);
    GUI gui = new ReversiGraphicsView(1000, 1000, controller);

    /*
    controller.placeToken(new HexCoords(1, -2));
    controller.placeToken(new HexCoords(2, -3));
    controller.placeToken(new HexCoords(1, -3));
    controller.placeToken(new HexCoords(0, -3));
    controller.placeToken(new HexCoords(-2, 1));
    controller.placeToken(new HexCoords(-3, 2));
    */

    gui.refresh();
  }
}