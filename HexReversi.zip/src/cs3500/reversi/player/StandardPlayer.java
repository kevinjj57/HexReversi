package cs3500.reversi.player;

import cs3500.reversi.controller.IController;
import cs3500.reversi.model.GameColors;
import cs3500.reversi.model.HexCoords;

/**
 * Represents the default behavior for any player, meaning a human OR an AI.
 */
public abstract class StandardPlayer implements IPlayer {
  GameColors color;
  IController controller;

  @Override
  public void assignColor(GameColors gc) {
    this.color = gc;
  }

  @Override
  public void assignController(IController cont) {
    this.controller = cont;
  }

  @Override
  public GameColors getColor() {
    checkGameStartedCorrectly();
    return this.color;
  }

  @Override
  public void placeToken(HexCoords coord) {
    checkGameStartedCorrectly();
    controller.placeToken(coord);
  }

  @Override
  public void pass() {
    checkGameStartedCorrectly();
    controller.pass();
  }

  protected void checkGameStartedCorrectly() {
    if (this.color == null || this.controller == null) {
      throw new IllegalStateException("Game must be instantiated before making moves");
    }
  }
}
