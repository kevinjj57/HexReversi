package cs3500.reversi.player;


import cs3500.reversi.controller.IController;
import cs3500.reversi.model.GameColors;
import cs3500.reversi.model.HexCoords;

/**
 * Represents a player for the game of Reversi. A player can either be a human or AI.
 */
//INTERFACE INVARIANT:
// A player cannot make a move unless it has been notified by the model that it is this
//person's turn.
//Additionally, an IPlayer can then make one placeToken move OR pass.
//then it may not make another move until it is notified by the model again.
public interface IPlayer {
  // wip interface, that is why JavaDocs are missing

  GameColors getColor();

  void assignColor(GameColors gc);

  void assignController(IController cont);

  void placeToken(HexCoords coord);

  void pass();

  void yourTurn();
}