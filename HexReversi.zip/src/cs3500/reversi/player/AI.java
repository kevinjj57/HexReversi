package cs3500.reversi.player;

import java.util.List;

import cs3500.reversi.model.HexCoords;
import cs3500.reversi.strategy.PlaceStrategy;

/**
 * Represents an AI player for a game of Reversi. AI's choose moves based on the strategies passed
 * to them or defaults to the first available most that is closest to top left.
 */
public class AI extends StandardPlayer {
  PlaceStrategy strategies;

  public AI(PlaceStrategy strat) {
    this.strategies = strat;
  }

  // picks the best move from the given list of strategies for the AI
  @Override
  public void yourTurn() {
    checkGameStartedCorrectly();
    if (controller.getROM().isGameOver()) {
      return;
    }
    List<HexCoords> validMoves = controller.getROM().getPossibleMoves();
    validMoves = strategies.getValidMoves(this.controller.getROM(), validMoves);
    if (validMoves.size() == 0) {
      pass();
    } else {
      placeToken(validMoves.get(0));
    }
  }
}
