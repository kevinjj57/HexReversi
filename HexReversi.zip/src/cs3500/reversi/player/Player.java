package cs3500.reversi.player;


import cs3500.reversi.controller.IController;
import cs3500.reversi.model.GameColors;
import cs3500.reversi.model.HexCoords;

/**
 * Represents a player in the game.
 * This is our current vision on how a Player class may look.
 * Has no impact on this homework.
 */
public class Player implements IPlayer {

  private GameColors color;
  private IController controller;

  @Override
  public GameColors getColor() {
    return this.color;
  }

  @Override
  public void assignColor(GameColors gc) {
    this.color = gc;
  }

  @Override
  public void assignController(IController cont) {
    this.controller = controller;
  }

  @Override
  public void placeToken(HexCoords coord) {
    checkGameStartedCorrectly();
    controller.placeToken(coord);
  }

  @Override
  public void pass() {
    checkGameStartedCorrectly();
    controller.pass();
  }

  @Override
  public void yourTurn() {
    //WIP
  }

  private void checkGameStartedCorrectly() {
    if (this.color == null || this.controller == null) {
      throw new IllegalStateException("Game must be instantiated before making moves");
    }
  }
}