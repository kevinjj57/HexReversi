package cs3500.reversi.controller;

import java.util.List;

import cs3500.reversi.model.GameColors;
import cs3500.reversi.model.HexCoords;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.player.IPlayer;
import cs3500.reversi.view.GUI;

/**
 * Work in progress controller we're using to configure our ideas.
 */
public class OutlineController implements IController {

  ReversiModel model;
  IPlayer[] players = new IPlayer[2];
  List<GUI> views;

  /**
   * Default constructor for the controller.
   * @param model reversi game model
   * @param p1 a player
   * @param p2 a player
   */
  public OutlineController(ReversiModel model, IPlayer p1, IPlayer p2) {
    this.model = model;
    this.players[0] = p1;
    p1.assignColor(GameColors.BLACK);
    p1.assignController(this);
    this.players[1] = p2;
    p2.assignColor(GameColors.WHITE);
    p2.assignController(this);
    notifyNextPlayer();
  }

  @Override
  public void placeToken(HexCoords hc) {
    model.placeToken(hc);
    notifyNextPlayer();
  }

  @Override
  public void pass() {
    model.pass();
    notifyNextPlayer();
  }

  @Override
  public ReversiROM getROM() {
    return model;
  }

  @Override
  public void getStarted() {
    //WIP
  }

  private void notifyNextPlayer() {
    GameColors color = model.whoseTurn();
    if (color == players[0].getColor()) {
      players[0].yourTurn();
    } else {
      players[1].yourTurn();
    }
  }
}
