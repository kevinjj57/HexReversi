package cs3500.reversi.controller;


import cs3500.reversi.model.HexCoords;
import cs3500.reversi.model.ReversiROM;

/**
 * The controller for a game of reversi. Deals with the distribution of information between the
 * view, model, and players.
 */
public interface IController {

  /**
   * Requesting the model for the current player to place a token at the given coordinates.
   * @param hc a cell's coordinate
   */
  void placeToken(HexCoords hc);

  /**
   * Requesting the model for the current player to pass their turn.
   */
  void pass();

  /**
   * Getting a readOnly version of the model that this controller is playing on.
   * @return the model in the identity of its readOnly interface so it is not to be mutated.
   */
  ReversiROM getROM();

  /**
   * Method to get view, controller, and model working together.
   */
  void getStarted();
}
