package cs3500.reversi.model;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.function.Function;

import cs3500.reversi.player.IPlayer;


/**
 * Reversi played on a hexagonal board.
 */
public final class Reversi implements ReversiModel {

  /**
   * Hexagonal Reversi Board.
   * See AxialCoords.jpeg in docs directory for coordinates.
   * The board map is q -> (r -> {@code GameColors})
   */
  // refer to axial coordinates jpeg
  // outer map represents q coordinate
  // inner map represents r coordinate to GameColor (White/Black)
  //INVARIANT:
  // if the absolute value of q, r, and (q + r), are all less than side length,
  // the coordinate will be on the board.
  private Map<Integer, Map<Integer, GameColors>> board;
  private final int sideLength;
  //INVARIANT: The player queue has a length of 2, and will only ever contain the two
  //IPlayers given in constructor.
  private Queue<GameColors> players = new ArrayDeque();
  private boolean gameOver;
  private boolean previousPlayPass;
  private int whiteScore;
  private int blackScore;

  /**
   * Constructor of starting the game.
   */
  public Reversi(int sideLength) {
    if (illegalSideLength(sideLength)) {
      throw new IllegalArgumentException("Bad Args.");
    }
    board = new MyHashMap<>();
    //Creates invariant of two players in this queue
    addPlayers();
    this.sideLength = sideLength;
    //Creates the board in accordance to the coordinate invariant.
    buildBoard();
  }

  /**
   * Copy constructor to allow for new models to be made that do not mutate this model.
   */
  public Reversi(ReversiROM model) {
    this.board = model.getBoard();
    this.sideLength = model.getSideLength();
    this.players = new ArrayDeque<>();
    players.add(model.whoseTurn());
    players.add(getOppColor(model.whoseTurn()));
    previousPlayPass = false;
    whiteScore = model.getScoreWhite();
    blackScore = model.getScoreBlack();
  }


  //Helper method to create invariant.
  private void addPlayers() {
    players = new ArrayDeque<>();
    players.add(GameColors.BLACK);
    players.add(GameColors.WHITE);
  }

  /**
   * Creates a certain sized hashmap (our unique MyHashMap).
   *
   * @param currentIndex the current hashmap index that this map is being placed at.
   * @return a map from an r-index to a token.
   */
  //Helps set the coordinate invariant.
  private Map<Integer, GameColors> makeSizedMyHashmap(int currentIndex) {
    return makeMtMap(getStartingIndex(currentIndex), getEndingIndex(currentIndex));
  }

  /**
   * Fills a hashmap will null tokens at the appropriate indexes.
   *
   * @param beginIndex r-index you wish to begin the row at.
   * @param endIndex   the r-index you wish to end the row at.
   * @return the MyHashMap that connects these indices and their null tokens.
   */
  //Helps set the coordinate invariant.
  private MyHashMap<Integer, GameColors> makeMtMap(int beginIndex, int endIndex) {
    MyHashMap<Integer, GameColors> hm = new MyHashMap<>();
    for (int index = beginIndex; index <= endIndex; index++) {
      hm.put(index, null);
    }
    return hm;
  }

  /**
   * Determines the max width a game board could be given a specific side length.
   * Can find the max number of q's in terms of r, or r in terms of q.
   *
   * @return the max cell width for a game
   */
  private int maxBoardWidth() {
    return (2 * this.sideLength) - 1;
  }

  /**
   * Returns the length of the board  at a specific q or r index. For example, at q = 0, the width
   * would be 7, as the board is 7 cells wide at q = 0.
   *
   * @param index determines the width of the given index.
   *              No matter which index you're measuring in, the max width in terms
   *              of that index will be the same.
   * @return the width.
   */
  private int widthOfIndex(int index) {
    return maxBoardWidth() - Math.abs(index);
  }

  /**
   * Places the initial tokens on the game board. Three black and three white tokens are placed
   * surrounding the center-most cell.
   * Additionally, adds the given points for the base tokens.
   * Uses putTokenHere because these are not valid player moves, and therefore placeToken
   * would throw an ISE.
   */
  private void placeInitialTokens() {
    GameColors currentColor = GameColors.BLACK;
    for (HexVectors direction : HexVectors.values()) {
      putTokenHere(currentColor, new HexCoords(direction.qChange, direction.rChange));
      currentColor = getOppColor(currentColor);
    }
    //There may be a better way to do this.
    blackScore = 3;
    whiteScore = 3;
  }

  /**
   * Constructs the HashMap that represents the game board. An empty cell is represented with null.
   */
  private void buildBoard() {
    int radius = this.sideLength - 1;
    for (int currentIndex = -1 * radius; currentIndex <= radius; currentIndex++) {
      board.put(currentIndex, makeSizedMyHashmap(currentIndex));
    }
    placeInitialTokens(); // every new board has the initial six tokens
  }

  /**
   * Determines if an illegal side length was given. For a game of Reversi, the side length must
   * be larger than 2 for it to be a valid game.
   *
   * @param sideLength the number of cells per side
   * @return the boolean for whether a side length is legal
   */
  private boolean illegalSideLength(int sideLength) {
    return sideLength < 2;
  }

  //Relies on IPlayer invariant.

  @Override
  public void placeToken(HexCoords coord) {
    if (isGameOver()) {
      throw new IllegalStateException("Game over");
    }
    if (getTokenAt(coord) != null) {
      throw new IllegalStateException("Token already there");
    }
    if (!legalCoords(coord)) {
      throw new IllegalArgumentException("Bad coords");
    }
    if (!legalPlacement(whoseTurn(), coord)) {
      throw new IllegalStateException("Invalid play.");
    }
    updateScore(coord);
    putTokenHere(whoseTurn(), coord);
    flipAll(coord);
    nextTurn();
    previousPlayPass = false;
  }

  @Override
  public void pass() {
    if (isGameOver()) {
      throw new IllegalStateException("Game over");
    }
    if (previousPlayPass) {
      gameOver = true;
    } else {
      nextTurn();
      previousPlayPass = true;
    }
  }

  @Override
  public int valueOfMove(HexCoords hc) {
    if (hc == null || !legalPlacement(whoseTurn(), hc)) {
      throw new IllegalArgumentException("Not a valid move");
    }
    return getActivatedTokens(whoseTurn(), hc).size();
  }

  @Override
  public GameColors whoseTurn() {
    return players.peek();
  }

  private void updateScore(HexCoords coords) {
    int scoreChange = getActivatedTokens(whoseTurn(), coords).size();
    if (whoseTurn() == GameColors.BLACK) {
      blackScore += scoreChange + 1;
      whiteScore -= scoreChange;
    } else {
      whiteScore += scoreChange + 1;
      blackScore -= scoreChange;
    }
  }

  private boolean legalPlacement(GameColors color, HexCoords coord) {
    return getActivatedTokens(color, coord).size() != 0;
  }

  private void flipAll(HexCoords coord) {
    List<HexCoords> affected = getActivatedTokens(whoseTurn(), coord);
    for (HexCoords token : affected) {
      flip(token);
    }
  }

  private List<HexCoords> getActivatedTokens(GameColors begColor, HexCoords hc) {
    List<HexCoords> ans = new ArrayList<>();
    for (HexVectors direction : HexVectors.values()) {
      ans.addAll(getAllInADirection(begColor, direction, hc, new ArrayList<>()));
    }
    return ans;
  }

  private List<HexCoords> getAllInADirection(
          GameColors begColor, HexVectors dir, HexCoords hc, List<HexCoords> ans) {
    HexCoords nextCoords = new HexCoords(hc.q + dir.qChange, hc.r + dir.rChange);
    if (legalCoords(nextCoords)) {
      GameColors nextToken = getTokenAt(nextCoords);
      if (nextToken != null) {
        if (nextToken == begColor) {
          return ans;
        } else {
          ans.add(nextCoords);
          return getAllInADirection(begColor, dir, nextCoords, ans);
        }
      }
    }
    return new ArrayList<>();
  }

  //Helper method to enforce given coordinates ensure the invariant.
  private boolean legalCoords(HexCoords coords) {
    return Math.abs(coords.q) < sideLength && Math.abs(coords.r) < sideLength
            && Math.abs(coords.q + coords.r) < sideLength;
  }

  @Override
  public int getSideLength() {
    return sideLength;
  }

  @Override
  public int getScoreBlack() {
    return blackScore;
  }

  @Override
  public int getScoreWhite() {
    return whiteScore;
  }

  @Override
  public boolean isGameOver() {
    return gameOver;
  }

  @Override
  public Map<Integer, Map<Integer, GameColors>> getBoard() {
    Map<Integer, Map<Integer, GameColors>> ans = new MyHashMap<Integer, Map<Integer, GameColors>>();
    for (Map.Entry<Integer, Map<Integer, GameColors>> entry : this.board.entrySet()) {
      ans.put(entry.getKey(), new MyHashMap<>());
      for (Map.Entry<Integer, GameColors> inside : entry.getValue().entrySet()) {
        ans.get(entry.getKey()).put(inside.getKey(), inside.getValue());
      }
    }
    return ans;
  }

  @Override
  public boolean isMoveLegal(HexCoords hc) {
    if (hc == null) {
      throw new IllegalArgumentException("Null Coords");
    }
    return legalCoords(hc) && getTokenAt(hc) == null && legalPlacement(whoseTurn(), hc);
  }

  public boolean anyLegalMoves2() {
    return checkWholeBoard((HexCoords hc) -> isMoveLegal(hc), true, false);
  }

  private <T> T checkWholeBoard(Function<HexCoords, Boolean> pred, T isFound, T notFound) {
    for (int r = -sideLength + 1; r < sideLength - 1; r++) {
      for (int q = getStartingIndex(r); q <= getEndingIndex(r); q++) {
        if (pred.apply(new HexCoords(q, r))) {
          return isFound;
        }
      }
    }
    return notFound;
  }
  
  /**
   * Gets the lowest index of the other type based on the given index.
   *   ex. on a board with side length four, the lowest index for r given a q of 0, is -3.
   *       on a board with side length four, the lowest index for q given an r of -2, is -1.
   *       on a board with side length four, the lowest index for q given an r of 3, is -3.
   * @param index the index number you wish to compare to.
   * @return the minimum index.
   */
  private int getStartingIndex(int index) {
    if (index < 0) {
      return -sideLength + 1 - index;
    } else {
      return -sideLength + 1;
    }
  }

  /**
   * Gets the highest index of the other type based on the given index.
   *   ex. on a board with side length four, the highest index for r given a q of 0, is 3.
   *       on a board with side length four, the highest index for q given an r of -2, is 3.
   *       on a board with side length four, the highest index for q given an r of 3, is 0.
   * @param index the index number you wish to compare to.
   * @return the maximum index.
   */
  private int getEndingIndex(int index) {
    if (index < 0) {
      return sideLength - 1;
    } else {
      return widthOfIndex(index) - sideLength;
    }
  }

  /**
   * Places a token at the given coordinates without checking if it is a legal move.
   *
   * @param coord a cell's coordinate.
   */
  private void putTokenHere(GameColors color, HexCoords coord) {
    if (getTokenAt(coord) != null) {
      throw new IllegalStateException("Token already there");
    }
    if (!legalCoords(coord)) {
      throw new IllegalArgumentException("Coords off board");
    }
    this.board.get(coord.q).put(coord.r, color);
  }

  /**
   * Same as getTokenAt, but this is a private method
   * that returns the actual token at that location.
   *
   * @param coords a cell's coordinate
   * @return the token at a specific cell
   */
  public GameColors getTokenAt(HexCoords coords) {
    if (coords == null || !legalCoords(coords)) {
      throw new IllegalArgumentException("Bad coords");
    }
    return this.board.get(coords.q).get(coords.r);
  }

  private void flip(HexCoords hc) {
    if (getTokenAt(hc) == null) {
      throw new IllegalStateException("Token not there");
    }
    this.board.get(hc.q).put(hc.r, getOppColor(getTokenAt(hc)));
  }

  private GameColors getOppColor(GameColors color) {
    if (color.equals(GameColors.BLACK)) {
      return GameColors.WHITE;
    } else {
      return GameColors.BLACK;
    }
  }

  //Upholds player number invariant.
  private void nextTurn() {
    this.players.add(this.players.remove());
  }

  /**
   * Tells a player that it is now their turn.
   *
   * @param p the player you wish to inform it is their turn.
   */
  private void nudgePlayer(IPlayer p) {
    p.yourTurn();
  }

  /**
   * Lists all possible moves in order from top left to bottom right.
   * @return the wished for list.
   */
  public List<HexCoords> getPossibleMoves() {
    List<HexCoords> ans = new ArrayList<>();
    for (int r = -this.getSideLength() + 1; r < this.getSideLength(); r++) {
      for (int q = getStartingIndex(r); q <= getEndingIndex(r); q++) {
        HexCoords hc = new HexCoords(q, r);
        if (this.isMoveLegal(hc)) {
          ans.add(hc);
        }
      }
    }
    return ans;
  }
}
