package cs3500.reversi.model;

import java.util.HashMap;

/**
 * An extension of HashMap that throws an IOB.
 *
 * @param <K> the type of keys maintained by this map
 * @param <V> the type of mapped values
 */
final class MyHashMap<K, V> extends HashMap {
  @Override
  public Object get(Object key) {
    if (super.containsKey(key)) {
      return super.get(key);
    } else {
      throw new IndexOutOfBoundsException("Index off the board");
    }
  }
}
