package cs3500.reversi.model;

import java.util.Objects;

/**
 * Represents the coordinate system for our game. This coordinate system is inspired by the
 * axial coordinate system from this article: https://www.redblobgames.com/grids/hexagons/
 * Refer to the AxialCoords.jpeg to see a visual of this system.
 */
public final class HexCoords {
  public final int q;
  public final int r;

  public HexCoords(int q, int r) {
    this.r = r;
    this.q = q;
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof HexCoords) {
      HexCoords object = (HexCoords) o;
      return object.q == this.q && object.r == r;
    } else {
      return false;
    }
  }

  @Override
  public int hashCode() {
    return Objects.hash(this, this.q, this.r);
  }
}
