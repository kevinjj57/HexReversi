package cs3500.reversi.model;

import java.util.List;
import java.util.Map;

/**
 * Mock model to allow for easier testing.
 */
public class MockReversi implements ReversiROM {

  private Map<Integer, Map<Integer, GameColors>> board;

  public MockReversi(Map<Integer, Map<Integer, GameColors>> board) {
    this.board = board;
  }

  /**
   * Returns a copy of the token at the coordinates.
   *
   * @param c the coordinates you wish to get the token from.
   * @return the copy.
   */
  @Override
  public GameColors getTokenAt(HexCoords c) {
    return board.get(c.q).get(c.r);
  }

  /**
   * Gets the side length of the game board. This is the number of cells wide/tall the hexagon
   * board is.
   *
   * @return side length
   */
  @Override
  public int getSideLength() {
    return (board.size() + 1) / 2;
  }

  /**
   * Gets the current score for black.
   *
   * @return black's score
   */
  @Override
  public int getScoreBlack() {
    return 0;
  }

  /**
   * Gets the current score for white.
   *
   * @return white's score
   */
  @Override
  public int getScoreWhite() {
    return 0;
  }

  /**
   * Determines if the game is over. A game of Reversi ends when two players pass back to back or
   * the board is full.
   *
   * @return if the game is over
   */
  @Override
  public boolean isGameOver() {
    return false;
  }

  /**
   * Gets a COPY of the board that this game is being played on.
   *
   * @return the copied board.
   */
  @Override
  public Map<Integer, Map<Integer, GameColors>> getBoard() {
    return Map.copyOf(board);
  }

  /**
   * States whether a move by the current player at these hexCoords is legal.
   *
   * @param hc the coordinates you wish to play at.
   * @return boolean stating whether the move was true.
   * @throws IllegalArgumentException if HexCoords are null.
   */
  @Override
  public boolean isMoveLegal(HexCoords hc) throws IllegalArgumentException {
    return false;
  }

  /**
   * Lists all possible moves in order from top left to bottom right.
   * if the returned list is empty, there are no possible moves for the player whose turn it is.
   *
   * @return the wished for list.
   */
  @Override
  public List<HexCoords> getPossibleMoves() {
    return null;
  }

  /**
   * States the value of a given move.
   *
   * @param hc the coordinates you wish to play at.
   * @return the value of the move.
   * @throws IllegalArgumentException if the move is not legal or HexCoords are null.
   */
  @Override
  public int valueOfMove(HexCoords hc) throws IllegalArgumentException {
    return 0;
  }

  /**
   * Shows what color's turn it is currently.
   *
   * @return the color of whose turn it is.
   */
  @Override
  public GameColors whoseTurn() {
    return GameColors.BLACK;
  }
}
