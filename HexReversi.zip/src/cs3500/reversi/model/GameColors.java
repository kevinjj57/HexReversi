package cs3500.reversi.model;

/**
 * Represents a game color for the game Reversi. A color can either be black or white.
 */
public enum GameColors {
    BLACK,
    WHITE;
}
