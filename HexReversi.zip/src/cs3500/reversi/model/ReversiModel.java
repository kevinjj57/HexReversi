package cs3500.reversi.model;

/**
 * Represents the primary model interface for a game of reversi that all
 * implementations should follow. This implementation of Reversi uses hexagon shaped cells as an
 * individual
 */
public interface ReversiModel extends ReversiROM {


  /**
   * Placing a token on the board.
   * @param coord the coordinates you wish to place this token.
   * @throws IllegalArgumentException if the coords are off the board.
   * @throws IllegalStateException if the coordinates already have a token at that location.
   */
  void placeToken(HexCoords coord);

  /**
   * Skips the current player's turn. When two players pass back to back, the game is over.
   */
  void pass();
}
