package cs3500.reversi.view;

import java.io.IOException;

import cs3500.reversi.model.GameColors;
import cs3500.reversi.model.HexCoords;
import cs3500.reversi.model.ReversiROM;

/**
 * Represents the simple textual view for the game Reversi. Outputs the game state as a string.
 */
public class HexTextView implements TextView {

  private ReversiROM model;

  public HexTextView(ReversiROM model) {
    this.model = model;
  }

  @Override
  public String toString() {
    Appendable ans = new StringBuffer(" ");
    int modelSideLength = model.getSideLength();
    for (int rIndex = -modelSideLength + 1; rIndex < modelSideLength; rIndex++) {
      addLeadingSpaces(ans, rIndex);
      for (int qIndex = -modelSideLength + 1; qIndex < modelSideLength; qIndex++) {
        if (Math.abs(qIndex + rIndex) < modelSideLength) {
          addStringTo(ans, colorToString(model.getTokenAt(new HexCoords(qIndex, rIndex))));
        }
      }
      addStringTo(ans, "\n");
    }
    return ans.toString();
  }

  private void addLeadingSpaces(Appendable ans, int vertIndex) {
    for (int height = Math.abs(vertIndex); height > 0; height--) {
      addStringTo(ans, "");
    }
  }

  /**
   * They way you'd like each color represented as a String.
   *
   * @param gc the color.
   * @return the given representation.
   */
  private String colorToString(GameColors gc) {
    if (gc == null) {
      return "_";
    } else {
      switch (gc) {
        case BLACK:
          return "X";
        case WHITE:
          return "O";
        default:
          throw new IllegalArgumentException("Not a good color enum.");
      }
    }
  }


  private void addStringTo(Appendable app, String s) {
    try {
      app.append(s + " ");
    } catch (IOException e) {
      throw new IllegalArgumentException("bad appendable");
    }
  }

}
