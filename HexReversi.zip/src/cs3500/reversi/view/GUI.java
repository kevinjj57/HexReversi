package cs3500.reversi.view;


/**
 * Represents the base GUI interface for creating our Swing GUI for Reversi.
 */
public interface GUI {
  /**
   * This method will be called when the drawing area has changed.
   * @param width canvas width
   * @param height canvas height
   */
  void setCanvasSize(int width, int height);

  /**
   * Refreshes the UI whenever a change occurs.
   */
  public void refresh();

}
