package cs3500.reversi.view;

/**
 * WIP Interface for Panel specific methods.
 */
public interface ReversiPanel {
}
