package cs3500.reversi.view;

/**
 * WIP interface for Frame specific methods.
 */
public interface ReversiFrame {

}
