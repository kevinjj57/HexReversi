package cs3500.reversi.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import cs3500.reversi.controller.IController;
import cs3500.reversi.model.GameColors;
import cs3500.reversi.model.HexCoords;

/**
 * Represents our graphical view for a game of Reversi using Java Swing.
 */
public class ReversiGraphicsView extends JFrame implements GUI {

  private JPanel panel;
  private IController controller;

  /**
   * Default constructor for our graphical view.
   *
   * @param width      width of the screen
   * @param height     height of the screen
   * @param controller controller for the game
   */
  public ReversiGraphicsView(int width, int height, IController controller) {
    super();
    this.controller = controller;
    setTitle("Reversi");
    setSize(width, height);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    panel = new MyHexPanel();
    JScrollPane scrolls = new JScrollPane(panel);
    this.add(scrolls);
    setVisible(true); // should set visible with a makeVisible method
  }

  @Override
  public void setCanvasSize(int width, int height) {
    panel.setPreferredSize(new Dimension(width, height));
    panel.revalidate();
    panel.repaint();
  }

  @Override
  public void refresh() {
    panel.updateUI();
  }


  private class MyHexPanel extends JPanel {
    private HexCoords hcc;

    MyHexPanel() {
      super();
      setBackground(Color.GRAY);
      this.addMouseListener(new MouseAdapter() {

        @Override
        public void mouseClicked(MouseEvent e) {
          Point clicked = e.getLocationOnScreen();
          clicked.x -= getWidth() / 2;
          clicked.y -= getHeight() / 2 + 3 * getMiniHexSL();
          int r = (clicked.y) / (3 * getMiniHexSL());
          int q = (clicked.x - (r * getMiniApothem())) / (2 * getMiniApothem());
          HexCoords newCoords = new HexCoords(q, r);
          if (hcc != null && hcc.equals(newCoords)) {
            hcc = null;
          } else {
            hcc = new HexCoords(q, r);
          }
          refresh();
        }
      });
      /*
      this.addKeyListener(new KeyAdapter() {
        /**
         * Invoked when a key has been typed.
         * This event occurs when a key press is followed by a key release.
         *
         * @param e key event
         */
      /*
        @Override
        public void keyTyped(KeyEvent e) {
          switch (e.getKeyCode()) {
            case (KeyEvent.VK_P):
              //pass
              break;
            case (KeyEvent.VK_ENTER):
              //placeToken(hcc)
              break;
          }
        }
      }); */
    }


    @Override
    public void paintComponent(Graphics g) {
      super.paintComponent(g);
      Graphics2D g2d = (Graphics2D) g;
      //Set origin to the center of the screen.
      g2d.translate(this.getWidth() / 2, this.getHeight() / 2);
      g2d.scale(1, 1);
      Map<Integer, Map<Integer, GameColors>> board = controller.getROM().getBoard();
      int sideLength = controller.getROM().getSideLength();
      int boardSize = panel.getHeight();
      int hexSize = Math.round(boardSize / (3 * sideLength));
      int apothem = Math.toIntExact(Math.round(Math.sqrt(3)) * hexSize);
      drawBoard(g2d, board);
    }

    private void drawBoard(Graphics2D g2d, Map<Integer, Map<Integer, GameColors>> board) {
      for (Integer q : board.keySet()) {
        for (Integer r : board.get(q).keySet()) {
          HexCoords hc = new HexCoords(q, r);
          Point point = xyOffset(hc);
          Polygon p = makeHex(xyOffset(hc));
          g2d.setColor(Color.BLACK);
          g2d.drawPolygon(p);
          if (hcc != null && hcc.q == q && hcc.r == r) {
            g2d.setColor(Color.CYAN);
            g2d.fillPolygon(p);
            System.out.println("HexCoords: (" + q + ", " + r + ")");
          }
          g2d.setColor(getColor(board.get(q).get(r)));
          g2d.fillOval(point.x - getMiniApothem() / 2, point.y - getMiniApothem() /
                  2, getMiniApothem(), getMiniApothem());
        }
      }
    }

    public Polygon makeHex(Point p) {
      int apothem = getMiniApothem();
      int sideL = getMiniHexSL();
      int cX = p.x;
      int cY = p.y;
      int[] xS = {cX, cX + apothem, cX + apothem, cX, cX - apothem, cX - apothem};
      int[] yS = {cY + 2 * sideL, cY + sideL, cY - sideL, cY - 2 * sideL, cY - sideL, cY + sideL};
      return new Polygon(xS, yS, 6);
    }

    public Point xyOffset(HexCoords hc) {
      Point ans = new Point(0, 0);
      ans.x += hc.q * 2 * getMiniApothem();
      ans.x += hc.r * getMiniApothem();
      ans.y += hc.r * 3 * getMiniHexSL();

      return ans;
    }

    private int getBoardHeight() {
      return panel.getHeight();
    }

    private int getMiniHexSL() {
      return Math.round(getBoardHeight() / (6 * controller.getROM().getSideLength()));
    }

    private int getMiniApothem() {
      return Math.toIntExact(panel.getWidth() /
              (2 * (2 * controller.getROM().getSideLength() - 1)));
    }


    private Color getColor(GameColors color) {
      if (color == null) {
        return new Color(0, 0, 0, 0);
      }
      switch (color) {
        case BLACK:
          return Color.BLACK;
        case WHITE:
          return Color.WHITE;
        default:
          throw new IllegalArgumentException("Bad Color");
      }
    }
  }
}
