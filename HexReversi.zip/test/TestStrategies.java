import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import cs3500.reversi.controller.IController;
import cs3500.reversi.controller.OutlineController;
import cs3500.reversi.model.GameColors;
import cs3500.reversi.model.HexCoords;
import cs3500.reversi.model.MockReversi;
import cs3500.reversi.model.Reversi;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.player.AI;
import cs3500.reversi.player.IPlayer;
import cs3500.reversi.player.Player;
import cs3500.reversi.strategy.AvoidNextToCorner;
import cs3500.reversi.strategy.ChainStrat;
import cs3500.reversi.strategy.GetCorner;
import cs3500.reversi.strategy.GetHighestScore;
import cs3500.reversi.strategy.MinMax;
import cs3500.reversi.strategy.MinMax2;
import cs3500.reversi.strategy.PlaceStrategy;
import cs3500.reversi.view.HexTextView;
import cs3500.reversi.view.TextView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Test class for our strategies.
 */
public class TestStrategies {
  ReversiModel model;
  TextView tv;
  IController cont1;

  @Before
  public void doEverything() {
    PlaceStrategy defaultStrat = new ChainStrat();
    PlaceStrategy highestScoreStrat = new ChainStrat(new GetHighestScore());
    PlaceStrategy avoidNearCornerStrat = new ChainStrat(new AvoidNextToCorner());
    PlaceStrategy getCornerStrat = new ChainStrat(new GetCorner());
    PlaceStrategy minMaxStrat = new ChainStrat(new MinMax());

    // ai with no strategies, defaults to top left-most available move
    AI defaultAI = new AI(defaultStrat);
    AI highestScoreAI = new AI(highestScoreStrat);
    AI avoidNearCornerAI = new AI(avoidNearCornerStrat);
    AI getCornerAI = new AI(getCornerStrat);
    AI minMaxAI = new AI(minMaxStrat);

    //AI allStrat = new AI();

    IPlayer p1 = new Player();

    model = new Reversi(4);
    cont1 = new OutlineController(model, highestScoreAI, p1);
    tv = new HexTextView(model);
  }

  // ------------------------------ GetHighestScore Tests -----------------------------------------

  /*
   * Tests the beginning of the game. The AI has three moves of equal score, so it breaks the tie
   * by defaulting to the one closest to the top left.
   */
  @Test
  public void testGetHighestScoreTieBreaker() {
    assertEquals(GameColors.BLACK, model.getTokenAt(new HexCoords(1, -2)));
    cont1.placeToken(new HexCoords(2, -3));
  }

  /*
   * Tests that GetHighestScore correctly returns all available moves at the beginning of the game,
   * this is because all possible moves are the same value.
   */
  @Test
  public void testGetHighestScoreStrategy() {
    ReversiModel testMod = new Reversi(4);
    PlaceStrategy strat = new GetHighestScore();
    List<HexCoords> lohc = strat.getValidMoves(testMod, testMod.getPossibleMoves());
    assertTrue(lohc.containsAll(Arrays.asList(
            new HexCoords(1, -2),
            new HexCoords(2, -1),
            new HexCoords(1, 1),
            new HexCoords(-1, 2),
            new HexCoords(-2, 1),
            new HexCoords(-1, -1))));
  }


  // ----------------------------- AvoidNextToCorner Tests --------------------------------------

  /*
   * Test a game state where there 5 moves available that would result in the AI placing next to a
   * corner. It will first confirm those moves are NOT a part of the transcript, and then make a
   * move that avoids placing next to a corner.
   */
  @Test
  public void testAvoidCorner() {
    Map<Integer, Map<Integer, GameColors>> board = model.getBoard();
    board.get(1).put(-2, GameColors.WHITE);
    board.get(1).put(-1, GameColors.WHITE);
    board.get(-1).put(-1, GameColors.WHITE);
    board.get(-2).put(0, GameColors.BLACK);
    board.get(1).put(1, GameColors.WHITE);
    board.get(-1).put(2, GameColors.WHITE);
    ReversiROM rom = new MockReversi(board);
    ReversiModel actM = new Reversi(rom);
    PlaceStrategy strat = new GetCorner();
    List<HexCoords> lohc = strat.getValidMoves(actM, actM.getPossibleMoves());
    assertFalse((Arrays.asList(
            new HexCoords(1, -3),
            new HexCoords(-1, -2),
            new HexCoords(0, -2),
            new HexCoords(1, 2),
            new HexCoords(-1, 3),
            new HexCoords(2, -3)).stream().anyMatch(hc -> lohc.contains(hc))));

  }

  /*
   * Tests a game state where there are no moves that would result in the AI placing a token next
   * to a corner. The AI will then default to our "fallback" strategy which is just the first top
   * left most move possible.
   */

  // --------------------------------- GetCorner Tests --------------------------------------------

  /*
   * Tests a game state where every corner is available to the AI (black). It will confirm
   * that every corner was checked by the corner strategy and that those coordinates are NOT
   * in the transcript.
   */
  @Test
  public void testGetCornerAllCornersAvailable() {
    Map<Integer, Map<Integer, GameColors>> board = model.getBoard();
    board.get(1).put(-3, GameColors.WHITE);
    board.get(2).put(-3, GameColors.BLACK);
    board.get(-1).put(-2, GameColors.BLACK);
    board.get(3).put(-2, GameColors.WHITE);
    board.get(-2).put(-1, GameColors.WHITE);
    board.get(3).put(-1, GameColors.BLACK);
    board.get(-3).put(1, GameColors.BLACK);
    board.get(2).put(1, GameColors.WHITE);
    board.get(-3).put(2, GameColors.WHITE);
    board.get(1).put(2, GameColors.BLACK);
    board.get(-2).put(3, GameColors.BLACK);
    board.get(-1).put(3, GameColors.WHITE);
    ReversiROM rom = new MockReversi(board);
    ReversiModel actM = new Reversi(rom);
    PlaceStrategy strat = new GetCorner();
    List<HexCoords> lohc = strat.getValidMoves(actM, actM.getPossibleMoves());
    assertTrue(lohc.containsAll(Arrays.asList(
            new HexCoords(0, -3),
            new HexCoords(3, -3),
            new HexCoords(-3, 0),
            new HexCoords(3, 0),
            new HexCoords(-3, 3),
            new HexCoords(0, 3))));
  }

  /*
   * Tests a game state where there are no available corners for the AI. The AI will then default
   * to our "fallback" strategy which is just the first top left most move possible.
   */


  // ----------------------------------- MinMax Tests --------------------------------------------

  /*
   * Tests a game where min max is finding the best possible move for another player given the
   * corner strategy and then making a move to minimize/prevent that move from occuring.
   */
  @Test
  public void testMinMaxAgainstCorner() {
    Map<Integer, Map<Integer, GameColors>> board = model.getBoard();
    board.get(1).put(-2, GameColors.WHITE);
    board.get(2).put(-3, GameColors.WHITE);
    ReversiROM rom = new MockReversi(board);
    ReversiModel actM = new Reversi(rom);
    PlaceStrategy strat = new MinMax2(new GetCorner());
    assertFalse(strat.getValidMoves(actM, actM.getPossibleMoves()).contains(new HexCoords(1, -3)));
  }


}