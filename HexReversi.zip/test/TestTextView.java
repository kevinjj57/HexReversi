import org.junit.Before;
import org.junit.Test;

import cs3500.reversi.model.HexCoords;
import cs3500.reversi.model.Reversi;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.view.HexTextView;
import cs3500.reversi.view.TextView;

import static junit.framework.TestCase.assertEquals;

/**
 * Tester class for HexTextView.
 */
public class TestTextView {

  private ReversiModel hexReversi;

  @Before
  public void initializeHexReversi() {
    hexReversi = new Reversi(4);
  }

  /**
   * Tests that the board displays as expected when a game is begun.
   */
  @Test
  public void testBeginBoard() {

    TextView tv = new HexTextView(hexReversi);
    String expAns =
                    "    _ _ _ _ \n" +
                    "   _ _ _ _ _ \n" +
                    "  _ _ X O _ _ \n" +
                    " _ _ O _ X _ _ \n" +
                    "  _ _ X O _ _ \n" +
                    "   _ _ _ _ _ \n" +
                    "    _ _ _ _ \n ";
    assertEquals(expAns, tv.toString());
  }

  @Test
  public void testBoardUpdates() {
    TextView tv = new HexTextView(hexReversi);
    hexReversi.placeToken(new HexCoords(2, -1));
    String expAns =
                    "    _ _ _ _ \n" +
                    "   _ _ _ _ _ \n" +
                    "  _ _ X X X _ \n" +
                    " _ _ O _ X _ _ \n" +
                    "  _ _ X O _ _ \n" +
                    "   _ _ _ _ _ \n" +
                    "    _ _ _ _ \n ";
    assertEquals(expAns, tv.toString());
  }

  @Test
  public void testBoardUpdatesBack() {
    TextView tv = new HexTextView(hexReversi);
    hexReversi.placeToken(new HexCoords(2, -1));
    hexReversi.placeToken(new HexCoords(1, -2));
    String expAns =
                    "    _ _ _ _ \n" +
                    "   _ _ O _ _ \n" +
                    "  _ _ O X X _ \n" +
                    " _ _ O _ X _ _ \n" +
                    "  _ _ X O _ _ \n" +
                    "   _ _ _ _ _ \n" +
                    "    _ _ _ _ \n ";
    assertEquals(expAns, tv.toString());
  }
}
