import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import cs3500.reversi.model.GameColors;
import cs3500.reversi.model.HexCoords;
import cs3500.reversi.model.Reversi;
import cs3500.reversi.model.ReversiModel;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;


/**
 * Tester class for the HexReversiModel.
 */
public class TestModel {
  // instance variable that we can use to initialize a new HexReversi for every test
  private ReversiModel hexReversi;

  @Before
  public void initializeHexReversi() {
    hexReversi = new Reversi(4);
  }

  // --------------------------------- Constructor Tests ------------------------------------------

  /**
   * Tests that the constructor creates the proper board with null tokens.
   */
  @Test
  public void testConstructorNulls() {
    assertNull(hexReversi.getTokenAt(new HexCoords(-3, 3)));
    assertNull(hexReversi.getTokenAt(new HexCoords(0, -3)));
    assertNull(hexReversi.getTokenAt(new HexCoords(-3, 0)));
    assertNull(hexReversi.getTokenAt(new HexCoords(3, -3)));
    assertNull(hexReversi.getTokenAt(new HexCoords(0, 3)));
    assertNull(hexReversi.getTokenAt(new HexCoords(3, 0)));
    assertNull(hexReversi.getTokenAt(new HexCoords(0, 0)));
  }

  /**
   * Tests the constructor doesn't map to anything out of bounds, and the proper illegal
   * argument exception throws when attempting to grab a token off the board.
   */
  @Test
  public void testConstructorOutOfBounds() {
    assertThrows("Out of bounds", IllegalArgumentException.class, () ->
            hexReversi.getTokenAt(new HexCoords(4, 0)));
    assertThrows("Out of bounds", IllegalArgumentException.class, () ->
            hexReversi.getTokenAt(new HexCoords(0, 4)));
  }

  // ----------------------------------- startGame Tests ------------------------------------------


  /**
   * Tests that invalid inputs to the HexReversi constructors throw a IAE.
   */
  @Test
  public void testStartGameInvalidSideLength() {
    assertThrows("Invalid side length", IllegalArgumentException.class, () ->
            new Reversi(1));
  }

  /**
   * Tests that startGame correctly places the initial tokens.
   */
  @Test
  public void testDefaultTokens() {
    assertNull(hexReversi.getTokenAt(new HexCoords(0, 0)));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(1, 0)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(0, 1)));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(-1, 1)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(-1, 0)));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(0, -1)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(1, -1)));
  }

  /**
   * Tests that a gameboard can be made as large as you want. With tokens in correct locations
   */
  @Test
  public void testBigBoard() {
    hexReversi = new Reversi(100);
    assertNull(hexReversi.getTokenAt(new HexCoords(55, -12)));
    assertNull(hexReversi.getTokenAt(new HexCoords(-99, 70)));
    assertNull(hexReversi.getTokenAt(new HexCoords(8, 23)));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(1, 0)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(0, 1)));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(-1, 1)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(-1, 0)));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(0, -1)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(1, -1)));
  }


  // --------------------------------- placeToken Tests ------------------------------------------

  /**
   * Tests that placing a token in a location your own token is already located throws ISE.
   */
  @Test
  public void testCantStackOwnTokens() {
    assertThrows(IllegalStateException.class, () ->
            hexReversi.placeToken(new HexCoords(1, 0)));
  }

  /**
   * Tests that placing a token in a location the other player already has a token located at
   * throws ISE.
   */
  @Test
  public void testCantStackOtherTokens() {
    hexReversi.pass();
    assertThrows(IllegalStateException.class, () ->
            hexReversi.placeToken(new HexCoords(0, 1)));
  }

  /**
   * Tests that placing a token in a location that does not create a sandwich throws ISE even
   * when surrounded by tokens.
   */
  @Test
  public void testInvalidMoveMiddle() {
    assertThrows(IllegalStateException.class, () ->
            hexReversi.placeToken(new HexCoords(0, 0)));
  }

  /**
   * Tests that placing a token in a location that does not create a sandwich throws ISE even
   * when on border.
   */
  @Test
  public void testInvalidMoveBoarder() {
    hexReversi.placeToken(new HexCoords(2, -1));
    assertThrows(IllegalStateException.class, () ->
            hexReversi.placeToken(new HexCoords(3, 0)));
  }

  /**
   * Tests that placing a token outside the grid throws an IndexOutOfBoundsException.
   */
  @Test
  public void testPlaceTokenOutOfBounds() {
    assertThrows(IllegalArgumentException.class, () ->
            hexReversi.placeToken(new HexCoords(6, -2)));
    assertThrows(IllegalArgumentException.class, () ->
            hexReversi.placeToken(new HexCoords(1, 8)));
    assertThrows(IllegalArgumentException.class, () ->
            hexReversi.placeToken(new HexCoords(10, 10)));
    assertThrows(IllegalArgumentException.class, () ->
            hexReversi.placeToken(new HexCoords(-10, -8)));
  }

  /**
   * Tests that a legal placement of the first token both places a new token and flips
   * the sandwiched token.
   */

  @Test
  public void testValidPlaceFirstToken() {
    hexReversi.placeToken(new HexCoords(2, -1));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(0, -1)));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(1, -1)));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(2, -1)));
  }

  /**
   * Tests that a sandwiching more than one token in one direction in a single move flips all
   * tokens in the middle.
   */
  @Test
  public void testSandwichMultipleTokensOneDirection() {
    hexReversi.placeToken(new HexCoords(2, -1));
    hexReversi.placeToken(new HexCoords(3, -2));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(0, 1)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(1, 0)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(2, -1)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(3, -2)));
  }

  /**
   * Tests to make sure tokens will flip in multiple directions from a single move.
   */
  @Test
  public void testSandwichMultipleTokensMultDirections() {
    hexReversi.placeToken(new HexCoords(2, -1));
    hexReversi.placeToken(new HexCoords(1, -2));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(0, -1)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(-1, 0)));
    hexReversi.placeToken(new HexCoords(-1, -1));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(0, -1)));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(-1, 0)));
  }

  /**
   * Tests that a valid move made on the border does not cause issues.
   */
  @Test
  public void testValidBoarderPlay() {
    hexReversi.placeToken(new HexCoords(2, -1));
    hexReversi.placeToken(new HexCoords(3, -2));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(0, 1)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(1, 0)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(2, -1)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(3, -2)));
  }


  // -----Pass


  // --------------------------------- getTokenAt Tests ------------------------------------------

  @Test
  public void testGetTokenAtThrowsHighR() {
    assertThrows(IllegalArgumentException.class, () -> hexReversi.getTokenAt(
            new HexCoords(0, 10)));
  }

  @Test
  public void testGetTokenAtThrowsHighQ() {
    assertThrows(IllegalArgumentException.class, () -> hexReversi.getTokenAt(
            new HexCoords(10, 0)));
  }

  @Test
  public void testGetTokenAtThrowsLowR() {
    assertThrows(IllegalArgumentException.class, () -> hexReversi.getTokenAt(
            new HexCoords(0, -10)));
  }

  @Test
  public void testGetTokenAtThrowsLowQ() {
    assertThrows(IllegalArgumentException.class, () -> hexReversi.getTokenAt(
            new HexCoords(-10, 0)));
  }

  @Test
  public void testGetTokenAtThrowsInvalidCoords() {
    assertThrows(IllegalArgumentException.class, () -> hexReversi.getTokenAt(
            new HexCoords(-2, -2)));
  }

  @Test
  public void testGetEmptyCellReturnsNull() {
    assertNull(hexReversi.getTokenAt(new HexCoords(0, 0)));
  }

  @Test
  public void testGetBlackCellReturnsBlack() {
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(0, -1)));
  }

  @Test
  public void testGetWhiteCellReturnsWhite() {
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(1, -1)));
  }

  @Test
  public void testGetFlippedWhiteGivesBlack() {
    hexReversi.placeToken(new HexCoords(1, -2));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(1, -1)));
  }

  @Test
  public void testGetFlippedBlackGivesWhite() {
    hexReversi.pass();
    hexReversi.placeToken(new HexCoords(1, -2));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(0, -1)));
  }

  // -------------------------------Score---------------------------------------------------------

  @Test
  public void testInitialScore() {
    assertEquals(3, hexReversi.getScoreBlack());
    assertEquals(3, hexReversi.getScoreWhite());
  }

  @Test
  public void testBlackScoreUpdates() {
    hexReversi.placeToken(new HexCoords(2, -1));
    assertEquals(5, hexReversi.getScoreBlack());
  }

  @Test
  public void testWhiteScoreUpdates() {
    hexReversi.pass();
    hexReversi.placeToken(new HexCoords(-1, 2));
    assertEquals(5, hexReversi.getScoreWhite());
  }

  @Test
  public void testPointsSteal() {
    assertEquals(3, hexReversi.getScoreBlack());
    assertEquals(3, hexReversi.getScoreWhite());
    hexReversi.placeToken(new HexCoords(2, -1));
    assertEquals(5, hexReversi.getScoreBlack());
    assertEquals(2, hexReversi.getScoreWhite());
    hexReversi.placeToken(new HexCoords(-1, 2));
    assertEquals(4, hexReversi.getScoreBlack());
    assertEquals(4, hexReversi.getScoreWhite());
  }

  @Test
  public void testPointsStolenWithMutipleSandwiches() {
    hexReversi.placeToken(new HexCoords(2, -1));
    assertEquals(5, hexReversi.getScoreBlack());
    assertEquals(2, hexReversi.getScoreWhite());
    hexReversi.placeToken(new HexCoords(3, -2));
    assertEquals(3, hexReversi.getScoreBlack());
    assertEquals(5, hexReversi.getScoreWhite());
  }

  //-----------------------------------Game Over

  @Test
  public void testGameOverBeginsFalse() {
    assertFalse(hexReversi.isGameOver());
  }

  @Test
  public void testDoublePassGameOver() {
    hexReversi.pass();
    assertFalse(hexReversi.isGameOver());
    hexReversi.pass();
    assertTrue(hexReversi.isGameOver());
  }

  /**
   * Tests that non-sequential passes does not cause game to end.
   */
  @Test
  public void testPassNotBack2Back() {
    hexReversi.pass();
    hexReversi.placeToken(new HexCoords(-1, -1));
    hexReversi.pass();
    assertFalse(hexReversi.isGameOver());
  }

  /**
   * Tests that you cannot place a token after the game ends.
   */
  @Test
  public void testGameOverNoPlaceToken() {
    hexReversi.pass();
    hexReversi.pass();
    assertThrows(IllegalStateException.class, () ->
            hexReversi.placeToken(new HexCoords(2, -1)));
  }

  /**
   * Tests that you pass after the game ends.
   */
  @Test
  public void testGameOverNoPassToken() {
    hexReversi.pass();
    hexReversi.pass();
    assertThrows(IllegalStateException.class, () -> hexReversi.pass());
  }

  //-- sidelength

  /**
   * Tests that a standard game with side length 4 returns the correct side length.
   */
  @Test
  public void testSideLengthBase() {
    assertEquals(4, hexReversi.getSideLength());
  }

  /**
   * Tests that a board built with a larger side length returns the correct side length.
   */
  @Test
  public void testSideLengthDif() {
    Reversi hr = new Reversi(100);
    assertEquals(100, hr.getSideLength());
  }

  //------- All direction sandwich tests
  @Test
  public void testSandwichUpLeft() {
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(1, -1)));
    hexReversi.placeToken(new HexCoords(1, -2));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(1, -1)));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(1, -2)));
  }

  @Test
  public void testSandwichUpRight() {
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(0, -1)));
    hexReversi.pass();
    hexReversi.placeToken(new HexCoords(1, -2));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(1, -2)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(0, -1)));
  }

  @Test
  public void testSandwichLeft() {
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(0, -1)));
    hexReversi.pass();
    hexReversi.placeToken(new HexCoords(-1, -1));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(0, -1)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(-1, -1)));
  }

  @Test
  public void testSandwichRight() {
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(1, -1)));
    hexReversi.placeToken(new HexCoords(2, -1));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(1, -1)));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(2, -1)));
  }

  @Test
  public void testSandwichDownLeft() {
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(-1, 0)));
    hexReversi.placeToken(new HexCoords(-2, 1));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(-1, 0)));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(-2, 1)));
  }

  @Test
  public void testSandwichDownRight() {
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(1, 0)));
    hexReversi.pass();
    hexReversi.placeToken(new HexCoords(1, 1));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(1, 1)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(1, 0)));
  }

  /**
   * This is a test to ensure that just because a white toke is between two
   * black tokens does not mean it gets flipped. For example, if White flips a Black token that
   * is in between two other Black tokens, that token stays WHITE.
   */
  @Test
  public void testSandwichNonExclusive() {
    hexReversi.placeToken(new HexCoords(1, 1));
    hexReversi.placeToken(new HexCoords(1, 2));
    hexReversi.placeToken(new HexCoords(2, -1));
    hexReversi.placeToken(new HexCoords(1, -2));
    //These tokens are in a row, but still alternate
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(2, -1)));
    assertEquals(GameColors.WHITE, hexReversi.getTokenAt(new HexCoords(1, 0)));
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(new HexCoords(0, 1)));
  }

  //-----------getBoard--------//
  @Test
  public void testGetBoardReturnsCopy() {
    Map<Integer, Map<Integer, GameColors>> board = hexReversi.getBoard();
    board.put(100, new HashMap<>());
    assertThrows(IndexOutOfBoundsException.class, () -> hexReversi.getBoard().get(100));
  }

  @Test
  public void testGetBoardImmutable() {
    HexCoords hc = new HexCoords(1, -2);
    hexReversi.placeToken(hc);
    Map<Integer, Map<Integer, GameColors>> board = hexReversi.getBoard();
    Set<Integer> soi = board.keySet();
    for (Integer i : soi) {
      i = null;
    }
    assertEquals(GameColors.BLACK, hexReversi.getTokenAt(hc));
  }

  //------- isMoveLegal -----------//

  /*

  getBoard;;
  boolean isMoveLegal(HexCoords hc);

    List<HexCoords> getPossibleMoves();

    int valueOfMove(HexCoords hc);
   */
  //-------- isMoveLegal ------//

  @Test
  public void testLegalMove() {
    assertTrue(hexReversi.isMoveLegal(new HexCoords(1, 1)));
  }

  @Test
  public void testIllegalMoveOnBoard() {
    assertFalse(hexReversi.isMoveLegal(new HexCoords(0, 0)));
  }

  @Test
  public void testIllegalMoveOffBoard() {
    assertFalse(hexReversi.isMoveLegal(new HexCoords(-2, -2)));
  }

  @Test
  public void testIsMoveLegalBadCoords() {
    assertFalse(hexReversi.isMoveLegal(new HexCoords(100, -100)));
  }

  @Test
  public void testIsMoveLegalNullCoords() {
    assertThrows(IllegalArgumentException.class, () -> hexReversi.isMoveLegal(null));
  }

  @Test
  public void testIsMoveLegalChecksForTheTurnPlayer() {
    hexReversi.placeToken(new HexCoords(1, -2));
    assertFalse(hexReversi.isMoveLegal(new HexCoords(-1, -1)));
    assertTrue(hexReversi.isMoveLegal(new HexCoords(2, -3)));
  }

  //-------  getPossibleMoves ------//

  @Test
  public void testContainsCorrectPossibleBlackMoves() {
    List<Boolean> lob = new ArrayList<>();
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(1, -2)));
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(-1, -1)));
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(2, -1)));
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(-2, 1)));
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(1, 1)));
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(-1, 2)));
    assertTrue(lob.stream().allMatch(b -> b));
  }

  @Test
  public void testContainsAllPossibleMovesAfterOneMove() {
    List<Boolean> lob = new ArrayList<>();
    hexReversi.placeToken(new HexCoords(1, -2));
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(2, -3)));
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(2, -1)));
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(-2, 1)));
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(-1, 2)));
    assertTrue(lob.stream().allMatch(b -> b));
  }

  @Test
  public void testGPMorder() {
    hexReversi.placeToken(new HexCoords(1, -2));
    List<HexCoords> exp = new ArrayList<>();
    exp.add(new HexCoords(2, -3));
    exp.add(new HexCoords(2, -1));
    exp.add(new HexCoords(-2, 1));
    exp.add(new HexCoords(-1, 2));
    assertEquals(exp, hexReversi.getPossibleMoves());
  }

  @Test
  public void testContainsCorrectPossibleWhiteMoves() {
    hexReversi.pass();
    List<Boolean> lob = new ArrayList<>();
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(1, -2)));
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(-1, -1)));
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(2, -1)));
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(-2, 1)));
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(1, 1)));
    lob.add(hexReversi.getPossibleMoves().contains(new HexCoords(-1, 2)));
    assertTrue(lob.stream().allMatch(b -> b));
  }

  @Test
  public void testOrderOfPossibileMovesTopLeftToBottomRight() {
    List<HexCoords> exp = new ArrayList<>();
    exp.add(new HexCoords(1, -2));
    exp.add(new HexCoords(-1, -1));
    exp.add(new HexCoords(2, -1));
    exp.add(new HexCoords(-2, 1));
    exp.add(new HexCoords(1, 1));
    exp.add(new HexCoords(-1, 2));
    assertEquals(exp, hexReversi.getPossibleMoves());
  }

  //-------- copyConstructor----//
  @Test
  public void testCopyModelIdentical() {
    ReversiModel newMod = new Reversi(hexReversi);
    assertEquals(hexReversi.whoseTurn(), newMod.whoseTurn());
    assertEquals(hexReversi.getPossibleMoves(), newMod.getPossibleMoves());
    assertEquals(hexReversi.isGameOver(), newMod.isGameOver());
    assertEquals(hexReversi.getSideLength(), newMod.getSideLength());
    assertEquals(hexReversi.getBoard(), newMod.getBoard());
    assertEquals(hexReversi.getScoreBlack(), newMod.getScoreBlack());
    assertEquals(hexReversi.getScoreWhite(), newMod.getScoreWhite());
  }

  @Test
  public void testCopyConstuctorPlayersImmutable() {
    ReversiModel newMod = new Reversi(hexReversi);
    newMod.pass();
    assertNotEquals(hexReversi.whoseTurn(), newMod.whoseTurn());
  }

  @Test
  public void testCopyConstructorBoardImmutable() {
    ReversiModel newMod = new Reversi(hexReversi);
    newMod.placeToken(new HexCoords(1, -2));
    assertNotEquals(hexReversi.getTokenAt(new HexCoords(1, -1)),
            newMod.getTokenAt(new HexCoords(1, -1)));
  }


  //-------- valueOfMove -------//

  @Test
  public void testValueOf() {
    assertEquals(1, hexReversi.valueOfMove(new HexCoords(1, -2)));
  }

  @Test
  public void testValueOfMultipleFlips() {
    hexReversi.placeToken(new HexCoords(-2, 1));
    assertEquals(2, hexReversi.valueOfMove(new HexCoords(-3, 1)));
  }

  @Test
  public void testValueOfInvalidMoveThrows() {
    assertThrows(IllegalArgumentException.class, () ->
            hexReversi.valueOfMove(new HexCoords(0, -3)));
  }
}
