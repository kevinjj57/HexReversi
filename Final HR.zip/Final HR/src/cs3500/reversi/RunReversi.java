package cs3500.reversi;

import java.util.HashMap;
import java.util.Map;

import cs3500.reversi.controller.IController;
import cs3500.reversi.controller.RevController;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.player.AI;
import cs3500.reversi.player.IPlayer;
import cs3500.reversi.player.Player;
import cs3500.reversi.shapes.CellShape;
import cs3500.reversi.shapes.Hex;
import cs3500.reversi.shapes.Square;
import cs3500.reversi.strategy.AvoidNextToCorner;
import cs3500.reversi.strategy.GetCorner;
import cs3500.reversi.strategy.GetHighestScore;
import cs3500.reversi.strategy.MinMax;
import cs3500.reversi.view.RevGUI;

/**
 * The actual runnable class of reversi.
 */
public final class RunReversi {
  /**
   * The method that allows you to run Reversi.
   * @param args Board Type:
   *               hex
   *               square
   *             SideLength
   *             Player1
   *             Player2
   */
  public static void main(String[] args) {
    CellShape shape = getShape(args[0]);
    ReversiModel model = shape.buildModel(Integer.parseInt(args[1]));
    if (args.length < 2) {
      System.out.println("Need Player Types");
      return;
    }
    IPlayer p1 = getPlayerType(args[2]);
    IPlayer p2 = getPlayerType(args[3]);
    if (p1 == null || p2 == null) {
      System.out.println("Invalid Player Type");
      return;
    }
    RevGUI view1 = shape.makeGUI(model);
    RevGUI view2 = shape.makeGUI(model);
    if (args.length > 4 && args[4].equals("hints")) {
      view1.displayHints();
      view2.displayHints();
    }
    IController cont1 = new RevController(model, p1, view1);
    IController cont2 = new RevController(model, p2, view2);
    model.startGame();
  }


  private static IPlayer getPlayerType(String s) {
    Map<String, IPlayer> knownPlayers = new HashMap<>();
    knownPlayers.put("human", new Player());
    knownPlayers.put("strategy1", new AI(new GetHighestScore()));
    knownPlayers.put("strategy2", new AI(new GetCorner()));
    knownPlayers.put("strategy3", new AI(new AvoidNextToCorner()));
    knownPlayers.put("strategy4", new AI(new MinMax(new GetHighestScore())));

    return knownPlayers.get(s);
  }

  private static CellShape getShape(String s0) {
    Map<String, CellShape> models = new HashMap<>();

    models.put("hex", new Hex());
    models.put("square", new Square());

    return models.get(s0);
  }
}