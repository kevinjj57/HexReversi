package cs3500.reversi.board;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import cs3500.reversi.shapes.CellShape;
import cs3500.reversi.shapes.Square;
import cs3500.reversi.utils.ICoords;
import cs3500.reversi.utils.SquareCoords;
import cs3500.reversi.utils.TokenStatus;

//Collumns -> Rows

/**
 * Represents the game board for a game of Reversi on a Square board. This is used to hide the
 * specific implementationn details of the board from the client.
 */
public class SquareBoard implements IBoard<Square> {

  private int sideLength;
  private TokenStatus[][] board;

  /**
   * Default constructor.
   * @param sideLength the game board's side length
   */
  public SquareBoard(int sideLength) {
    this.sideLength = sideLength;
    this.board = new TokenStatus[sideLength][sideLength];
    for (TokenStatus[] tsa : board) {
      for (int i = 0; i < sideLength; i++) {
        tsa[i] = TokenStatus.EMPTY;
      }
    }
  }

  /**
   * Gets the color of a piece at the given HexCoords on the Board.
   *
   * @param hc the axial coordinate of the piece you would like to get.
   * @return the color or null if the space is empty.
   * @throws IndexOutOfBoundsException if the coordinate is off the board.
   */
  @Override
  public TokenStatus getPieceAt(ICoords<Square> hc) throws IndexOutOfBoundsException {
    if (!validCoords(hc)) {
      System.out.println(hc.getFirst());
      System.out.println(hc.getSecond());
      throw new IndexOutOfBoundsException();
    }
    return board[hc.getFirst()][hc.getSecond()];
  }

  /**
   * Gets the side length of this hexagonal board.
   *
   * @return the appropriate side length.
   */
  @Override
  public int getSideLength() {
    return sideLength;
  }

  /**
   * /**
   * Adds a token of the given color to this board.
   *
   * @param hc the coordinates you wish to add the colored token at.
   * @param gc the GameColor of the token.
   * @throws IndexOutOfBoundsException if the coordinates are off the board.
   */
  @Override
  public void addToBoard(ICoords<Square> hc, TokenStatus gc) throws IndexOutOfBoundsException {
    board[hc.getFirst()][hc.getSecond()] = gc;
  }


  /**
   * Copies this board.
   *
   * @return a copy of this board.
   */
  @Override
  public IBoard copyBoard() {
    IBoard ans = new SquareBoard(sideLength);
    for (Object coord : getValidCoords()) {
      SquareCoords sc = (SquareCoords) coord;
      ans.addToBoard(sc, getPieceAt(sc));
    }
    return ans;
  }

  /**
   * Gets all the valid coordinates of this board.
   * The purpose of this method is to allow for separation of board and view.
   *
   * @return a set of all coordinates.
   */
  @Override
  public Set<ICoords<Square>> getValidCoords() {
    Set ans = new HashSet<>();
    for (int i1 = 0; i1 < sideLength; i1++) {
      for (int i2 = 0; i2 < sideLength; i2++) {
        ans.add(new SquareCoords(i1, i2));
      }
    }
    return ans;
  }

  @Override
  public List<ICoords<Square>> getCorners() {
    CellShape hex = new Square();
    List<ICoords<Square>> ans = new ArrayList<>();
    int offset = sideLength - 1;
    ans.add(hex.makeCoord(0, 0));
    ans.add(hex.makeCoord(0, offset));
    ans.add(hex.makeCoord(offset, 0));
    ans.add(hex.makeCoord(offset, offset));
    return ans;
  }

  private boolean validCoords(ICoords<Square> coords) {
    return coords.getFirst() >= 0
            && coords.getFirst() < sideLength
            && coords.getSecond() >= 0
            && coords.getSecond() < sideLength;
  }
}
