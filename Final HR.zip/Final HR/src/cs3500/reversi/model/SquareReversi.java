package cs3500.reversi.model;

import cs3500.reversi.shapes.CellShape;
import cs3500.reversi.shapes.Square;
import cs3500.reversi.utils.SquareCoords;
import cs3500.reversi.utils.TokenStatus;

/**
 * Specific implementations for our square reversi model.
 */
public class SquareReversi extends Reversi<Square> {

  /**
   * Default constructor for a game of Reversi.
   *
   * @param sideLength the game board side length.
   * @throws IllegalArgumentException if the sideLength is odd.
   */
  public SquareReversi(int sideLength) {
    super(sideLength);
    if (sideLength % 2 != 0) {
      throw new IllegalArgumentException();
    }
    cb = new Square();
    setUpGame();
  }

  public SquareReversi(ReversiROM model) {
    super(model);
  }

  @Override
  protected void placeInitialTokens() {
    int top = getSideLength() / 2;
    int bot = (getSideLength() / 2) - 1;
    putTokenHere(TokenStatus.BLACK, new SquareCoords(bot, top));
    putTokenHere(TokenStatus.WHITE, new SquareCoords(bot, bot));
    putTokenHere(TokenStatus.BLACK, new SquareCoords(top, bot));
    putTokenHere(TokenStatus.WHITE, new SquareCoords(top, top));
  }

  @Override
  public CellShape getShape() {
    return cb;
  }

  @Override
  public ReversiModel copy() {
    return new SquareReversi(this);
  }
}
