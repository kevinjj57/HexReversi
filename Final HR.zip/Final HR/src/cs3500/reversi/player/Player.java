package cs3500.reversi.player;

/**
 * Represents a player in the game.
 * This is our current vision on how a Player class may look.
 * Has no impact on this homework.
 */
public class Player extends StandardPlayer {

}