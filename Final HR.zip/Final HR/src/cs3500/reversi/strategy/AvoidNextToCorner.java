package cs3500.reversi.strategy;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import cs3500.reversi.shapes.CellShape;
import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.utils.ICoords;

/**
 * Represents the strategy that avoids the cells next to a corner.
 */
public class AvoidNextToCorner implements PlaceStrategy {


  /**
   * Gets all possible coordinates that creates Valid moves on the given ReversiModel
   * in accordance to the strategy. Listed in order from top left to bottom right.
   *
   * @param model      the model portion of Reversi
   * @param validMoves a list of valid moves
   * @return the list of all possible moves given a specific strategy
   */
  @Override
  public List<ICoords> getValidMoves(ReversiROM model, List validMoves) {
    List<ICoords> vm = List.copyOf(validMoves);
    List<ICoords> corners = model.getBoard().getCorners();
    CellShape shape = model.getShape();
    List<ICoords> nextTos = new ArrayList<>();
    for (ICoords coord : corners) {
      for (ICoords vec : shape.getVectors()) {
        ICoords curr =
                shape.makeCoord(coord.getFirst() + vec.getFirst(),
                        coord.getSecond() + vec.getSecond());
        if (model.isMoveLegal(curr)) {
          nextTos.add(curr);
        }
      }
    }
    List<ICoords> ans = vm.stream().filter((ICoords c) ->
            !nextTos.contains(c)).collect(Collectors.toList());
    return ans;
  }
}
