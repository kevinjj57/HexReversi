/**
 * An example class to show valid and invalid interactions with the model.
 */
public class ExampleModel {

  // Note: You can call toString on the model to see our examples in a textual view.

  // *** Refer to GAMEPLAY.txt to see what happens to the board when a token is placed and someone
  // passes ***

  /*
   * Example constructor:
   * - integer represents the side length of the board. In this case, the hexagon will be 4 cells
   *   wide. It must be greater than or equal to two for it to be a valid side length.
   * - the two player parameters represent two players being passed into the model. Later on, a
   * player will EITHER be a two humans playing against each other or one human against one AI.
   * A player cannot be null.
   */
/*
  void exampleConstructor() {
    // VALID
    ReversiModel model1 = new Reversi(4, new Player(), new Player());

    // VALID
    ReversiModel model2 = new Reversi(2, new Player(), new Player());

    // VALID
    ReversiModel model3 = new Reversi(100, new Player(), new Player());

    // INVALID side length
    ReversiModel model4 = new Reversi(1, new Player(), new Player());

    // INVALID player
    ReversiModel model5 = new Reversi(2, null, new Player());

    // INVALID player
    ReversiModel model6 = new Reversi(2, new Player(), null);
  }

  /*
   * Example place token:
   * - color represents the current player's token color.
   * - coord is the coordinates of the cell you are attempting to place a token at. You may only
   * place a token on a cell within the bounds of the game board, where there is no token currently,
   * and that it is a valid move in the rules of the game (ie form a sandwich)
   *
   * The first token being placed must be played by black
   *
   *  ** REFER TO AxialCoords.jpeg for coordinate locations for (q, r) **
   */
  /*
  void examplePlaceToken() {
    ReversiModel model1 = new Reversi(4, new Player(), new Player());

    // Each example is independent of one another

    // VALID
    model1.placeToken(GameColors.BLACK, new HexCoords(2, -1));

    // VALID
    model1.placeToken(GameColors.BLACK, new HexCoords(1, -1));

    // INVALID, first move must be made by black
    model1.placeToken(GameColors.WHITE, new HexCoords(2, -1));

    // INVALID, out of bounds coord
    model1.placeToken(GameColors.BLACK, new HexCoords(100, -1));

    // INVALID, empty cell but not a valid sandwich
    model1.placeToken(GameColors.BLACK, new HexCoords(3, -1));
  }

  /*
   * Example pass:
   * - color represents the current player's token color
   *
   * Pass may be called at anytime during the game to skip a player's turn. However, if both players
   * call pass back to back, the game immediately ends.
   */
  /*
  void examplePass() {
    ReversiModel model1 = new Reversi(4, new Player(), new Player());

    // VALID
    model1.pass(GameColors.BLACK);

    // VALID
    // below represents black making a valid move and then white skipping
    model1.placeToken(GameColors.BLACK, new HexCoords(2, -1));
    model1.pass(GameColors.WHITE);

    // VALID, game over
    model1.pass(GameColors.BLACK);
    model1.pass(GameColors.WHITE);

    // INVALID, cannot pass three times in a row
    model1.pass(GameColors.BLACK);
    model1.pass(GameColors.WHITE);
    model1.pass(GameColors.BLACK);

    // INVALID, same player cannot pass twice
    model1.pass(GameColors.BLACK);
    model1.pass(GameColors.BLACK);
  }
  */
}
