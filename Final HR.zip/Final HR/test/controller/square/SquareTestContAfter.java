package controller.square;

import org.junit.Test;

import controller.ModelForTesting;
import controller.TestControllerAfterStart;
import cs3500.reversi.controller.IController;
import cs3500.reversi.controller.RevController;
import cs3500.reversi.model.SquareReversi;
import cs3500.reversi.player.Player;
import cs3500.reversi.view.FakeView;

import static org.junit.Assert.assertEquals;

/**
 * Test for a square controller after start.
 */
public class SquareTestContAfter extends TestControllerAfterStart {

  public SquareTestContAfter() {
    super();
    mockDeli = new ModelForTesting(4, new SquareReversi(4));
  }

  @Test
  public void testStartGame() {
    ModelForTesting mock = new ModelForTesting(4, new SquareReversi(4));
    IController cont2 = new RevController(mock, new Player(), new FakeView());
    IController cont3 = new RevController(mock, new Player(), new FakeView());
    assertEquals("", mock.transcript.toString());
    mock.startGame();
    assertEquals("Game Started\n", mock.transcript.toString());
  }
}
