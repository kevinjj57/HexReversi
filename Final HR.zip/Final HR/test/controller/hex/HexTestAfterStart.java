package controller.hex;

import org.junit.Test;

import controller.ModelForTesting;
import controller.TestControllerAfterStart;
import cs3500.reversi.controller.IController;
import cs3500.reversi.controller.RevController;
import cs3500.reversi.model.HexReversi;
import cs3500.reversi.player.Player;
import cs3500.reversi.utils.HexCoords;
import cs3500.reversi.utils.TokenStatus;
import cs3500.reversi.view.FakeView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

/**
 * Tests for after the start of a hex controller.
 */
public class HexTestAfterStart extends TestControllerAfterStart {

  public HexTestAfterStart() {
    super();
    mockDeli = new ModelForTesting(4, new HexReversi(4));
  }

  @Test
  public void testStartGame() {
    ModelForTesting mock = new ModelForTesting(4, new HexReversi(4));
    IController cont2 = new RevController(mock, new Player(), new FakeView());
    IController cont3 = new RevController(mock, new Player(), new FakeView());
    assertEquals("", mock.transcript.toString());
    mock.startGame();
    assertEquals("Game Started\n", mock.transcript.toString());
  }

  @Test
  public void testGoodPlaceTokenFeatureUpdatesModel() {
    HexCoords hc = new HexCoords(1, -2);
    assertTrue(mockDeli.isMoveLegal(hc));
    assertEquals(mockDeli.whoseTurn(), cont0.getColor());
    cont0.placeToken(hc);
    assertEquals(mockDeli.getTokenAt(hc), TokenStatus.BLACK);
    assertEquals(mockDeli.getTokenAt(new HexCoords(1, -1)), TokenStatus.BLACK);
  }

  @Test
  public void testBadPlacementPlaceTokenFeatureDoesntUpdateModel() {
    HexCoords hc = new HexCoords(3, -3);
    assertFalse(mockDeli.isMoveLegal(hc));
    assertEquals(mockDeli.whoseTurn(), cont0.getColor());
    cont0.placeToken(hc);
    assertEquals(mockDeli.getTokenAt(hc), TokenStatus.EMPTY);
  }

  @Test
  public void testTokenOnToken() {
    HexCoords hc = new HexCoords(1, -1);
    assertFalse(mockDeli.isMoveLegal(hc));
    assertEquals(mockDeli.whoseTurn(), cont0.getColor());
    cont0.placeToken(hc);
    assertEquals(mockDeli.whoseTurn(), cont0.getColor());
    assertEquals(TokenStatus.WHITE, mockDeli.getTokenAt(hc));
  }

  @Test
  public void testWrongTurnPlay() {
    HexCoords hc = new HexCoords(1, -2);
    assertNotEquals(mockDeli.whoseTurn(), cont1.getColor());
    cont1.placeToken(hc);
    assertEquals(mockDeli.getTokenAt(hc), TokenStatus.EMPTY);
  }

  @Test
  public void testWrongTurnPass() {
    assertNotEquals(mockDeli.whoseTurn(), cont1.getColor());
    cont1.pass();
    assertNotEquals(mockDeli.whoseTurn(), cont1.getColor());
  }

  @Test
  public void testPlayerActivatesContPlay() {
    assertEquals("", cont0.app.toString());
    HexCoords hc = new HexCoords(1, -2);
    p0.placeToken(hc);
    assertTrue(cont0.app.toString().contains("Given Move: PlaceToken"));
  }

  @Test
  public void testPlayerCantPlayIfNotTurn() {
    assertNotEquals(p1.getColor(), mockDeli.whoseTurn());
    HexCoords hc = new HexCoords(1, -2);
    p1.placeToken(hc);
    assertNotEquals(p1.getColor(), mockDeli.whoseTurn());
    assertEquals(TokenStatus.EMPTY, mockDeli.getTokenAt(hc));
  }


  @Test
  public void testViewToContFeaturesPlay() {
    HexCoords hc = new HexCoords(1, -2);
    assertEquals(TokenStatus.EMPTY, mockDeli.getTokenAt(hc));
    cont0.placeToken(hc);
    assertEquals(TokenStatus.BLACK, mockDeli.getTokenAt(hc));
  }


  @Test
  public void testTokenOnTokenNotifiesViewToDisplayErrorMessage() {
    assertFalse(view0.app.toString().contains("Message Displayed: Token already there"));
    cont0.placeToken(new HexCoords(0, -1));
    assertTrue(view0.app.toString().contains("Message Displayed: Token already there"));

  }

  @Test
  public void testInvalidMoveNotifiesViewToDisplayErrorMessage() {
    assertFalse(view0.app.toString().contains("Message Displayed: Invalid play"));
    cont0.placeToken(new HexCoords(3, -3));
    assertTrue(view0.app.toString().contains("Message Displayed: Invalid play"));
  }


  @Test
  public void testGameOverDisplaysBlackWin() {
    assertFalse(view0.app.toString().contains("Black Wins!"));
    cont0.placeToken(new HexCoords(1, -2));
    cont0.gameOver();
    assertTrue(view0.app.toString().contains("Black Wins!"));
  }

  @Test
  public void testGameOverDisplaysWhiteWin() {
    assertFalse(view0.app.toString().contains("White Wins!"));
    cont0.pass();
    cont1.placeToken(new HexCoords(1, -2));
    cont0.gameOver();
    assertTrue(view0.app.toString().contains("White Wins!"));
  }

  @Test
  public void testErrorMessageDoesntDisplayOnOtherView() {
    assertFalse(view1.app.toString().contains("Message Displayed: Token Already There"));
    cont0.placeToken(new HexCoords(0, -1));
    assertFalse(view1.app.toString().contains("Message Displayed: Token Already There"));
  }
}
