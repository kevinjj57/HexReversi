package controller;

import java.io.IOException;

import cs3500.reversi.controller.PlayerFeatures;
import cs3500.reversi.view.RevGUI;

/**
 * Represents a mock view for testing purposes.
 */
public class ViewForTesting implements RevGUI {


  PlayerFeatures contListener;
  public Appendable app = new StringBuilder();

  @Override
  public void render() {
    // don't need this method for mock, do nothing
  }

  @Override
  public void setCommandListener(PlayerFeatures feat) {
    contListener = feat;
  }


  @Override
  public void showMessage(String message) {
    append("Message Displayed: " + message);
  }

  private void append(String s) {
    try {
      app.append(s + "\n");
    } catch (IOException e) {
      throw new IllegalStateException();
    }
  }

  /**
   * Sets this view into focus so it may be subjected to Mouse and Key inputs.
   */
  @Override
  public void setFocus() {
    // don't need this method for mock, do nothing
  }

  /**
   * Removes this view from focus so players cannot interact
   * with this view when it is not their turn.
   */
  @Override
  public void removeFocus() {
    // don't need this method for mock, do nothing
  }
}

