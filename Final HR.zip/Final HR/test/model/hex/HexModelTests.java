package model.hex;

import org.junit.Test;

import cs3500.reversi.model.HexReversi;
import cs3500.reversi.model.Reversi;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.utils.HexCoords;
import cs3500.reversi.utils.TokenStatus;
import model.TestModel;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

/**
 * Tests for a hexmodel.
 */
public class HexModelTests extends TestModel {

  public HexModelTests() {
    super();
    model = new HexReversi(4);
  }

  /**
   * Tests that all methods pertaining to the gameplay itself will throw ISE if called before
   * the game has been started.
   */
  @Test
  public void testPreStartGameThrows() {
    ReversiModel rm = new HexReversi(4);
    assertThrows(IllegalStateException.class, () -> rm.placeToken(new HexCoords(-2, 1)));
    assertThrows(IllegalStateException.class, () -> rm.pass());
    assertThrows(IllegalStateException.class, () -> rm.pass());
    assertThrows(IllegalStateException.class, () -> rm.pass());
    assertThrows(IllegalStateException.class, () -> rm.pass());
  }

  // --------------------------------- Constructor Tests ------------------------------------------

  /**
   * Tests that the constructor creates the proper board with null tokens.
   */
  @Test
  public void testConstructorNulls() {
    assertEquals(TokenStatus.EMPTY, model.getTokenAt(new HexCoords(-3, 3)));
    assertEquals(TokenStatus.EMPTY, model.getTokenAt(new HexCoords(0, -3)));
    assertEquals(TokenStatus.EMPTY, model.getTokenAt(new HexCoords(-3, 0)));
    assertEquals(TokenStatus.EMPTY, model.getTokenAt(new HexCoords(3, -3)));
    assertEquals(TokenStatus.EMPTY, model.getTokenAt(new HexCoords(0, 3)));
    assertEquals(TokenStatus.EMPTY, model.getTokenAt(new HexCoords(3, 0)));
    assertEquals(TokenStatus.EMPTY, model.getTokenAt(new HexCoords(0, 0)));
  }

  /**
   * Tests the constructor doesn't map to anything out of bounds, and the proper illegal
   * argument exception throws when attempting to grab a token off the board.
   */
  @Test
  public void testConstructorOutOfBounds() {
    assertThrows("Out of bounds", IllegalArgumentException.class, () ->
            model.getTokenAt(new HexCoords(4, 0)));
    assertThrows("Out of bounds", IllegalArgumentException.class, () ->
            model.getTokenAt(new HexCoords(0, 4)));
  }


  /**
   * Tests that invalid inputs to the HexReversi constructors throw a IAE.
   */
  @Test
  public void testStartGameInvalidSideLength() {
    assertThrows("Invalid side length", IllegalArgumentException.class, () ->
            new HexReversi(1));
  }

  /**
   * Tests that startGame correctly places the initial tokens.
   */
  @Test
  public void testDefaultTokens() {
    assertEquals(TokenStatus.EMPTY, model.getTokenAt(new HexCoords(0, 0)));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(1, 0)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(0, 1)));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(-1, 1)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(-1, 0)));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(0, -1)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(1, -1)));
  }

  /**
   * Tests that a gameboard can be made as large as you want. With tokens in correct locations
   */
  @Test
  public void testBigBoard() {
    model = new HexReversi(100);
    assertEquals(TokenStatus.EMPTY, model.getTokenAt(new HexCoords(55, -12)));
    assertEquals(TokenStatus.EMPTY, model.getTokenAt(new HexCoords(-99, 70)));
    assertEquals(TokenStatus.EMPTY, model.getTokenAt(new HexCoords(8, 23)));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(1, 0)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(0, 1)));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(-1, 1)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(-1, 0)));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(0, -1)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(1, -1)));
  }


  // --------------------------------- placeToken Tests ------------------------------------------

  /**
   * Tests that placing a token in a location your own token is already located throws ISE.
   */
  @Test
  public void testCantStackOwnTokens() {
    assertThrows(IllegalStateException.class, () ->
            model.placeToken(new HexCoords(1, 0)));
  }

  /**
   * Tests that placing a token in a location the other player already has a token located at
   * throws ISE.
   */
  @Test
  public void testCantStackOtherTokens() {
    model.pass();
    assertThrows(IllegalStateException.class, () ->
            model.placeToken(new HexCoords(0, 1)));
  }

  /**
   * Tests that placing a token in a location that does not create a sandwich throws ISE even
   * when surrounded by tokens.
   */
  @Test
  public void testInvalidMoveMiddle() {
    assertThrows(IllegalStateException.class, () ->
            model.placeToken(new HexCoords(0, 0)));
  }

  /**
   * Tests that placing a token in a location that does not create a sandwich throws ISE even
   * when on border.
   */
  @Test
  public void testInvalidMoveBoarder() {
    model.placeToken(new HexCoords(2, -1));
    assertThrows(IllegalStateException.class, () ->
            model.placeToken(new HexCoords(3, 0)));
  }

  /**
   * Tests that placing a token outside the grid throws an IndexOutOfBoundsException.
   */
  @Test
  public void testPlaceTokenOutOfBounds() {
    assertThrows(IllegalArgumentException.class, () ->
            model.placeToken(new HexCoords(6, -2)));
    assertThrows(IllegalArgumentException.class, () ->
            model.placeToken(new HexCoords(1, 8)));
    assertThrows(IllegalArgumentException.class, () ->
            model.placeToken(new HexCoords(10, 10)));
    assertThrows(IllegalArgumentException.class, () ->
            model.placeToken(new HexCoords(-10, -8)));
  }

  /**
   * Tests that a legal placement of the first token both places a new token and flips
   * the sandwiched token.
   */

  @Test
  public void testValidPlaceFirstToken() {
    model.placeToken(new HexCoords(2, -1));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(0, -1)));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(1, -1)));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(2, -1)));
  }

  /**
   * Tests that a sandwiching more than one token in one direction in a single move flips all
   * tokens in the middle.
   */
  @Test
  public void testSandwichMultipleTokensOneDirection() {
    model.placeToken(new HexCoords(2, -1));
    model.placeToken(new HexCoords(3, -2));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(0, 1)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(1, 0)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(2, -1)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(3, -2)));
  }

  /**
   * Tests to make sure tokens will flip in multiple directions from a single move.
   */
  @Test
  public void testSandwichMultipleTokensMultDirections() {
    model.placeToken(new HexCoords(2, -1));
    model.placeToken(new HexCoords(1, -2));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(0, -1)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(-1, 0)));
    model.placeToken(new HexCoords(-1, -1));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(0, -1)));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(-1, 0)));
  }

  /**
   * Tests that a valid move made on the border does not cause issues.
   */
  @Test
  public void testValidBoarderPlay() {
    model.placeToken(new HexCoords(2, -1));
    model.placeToken(new HexCoords(3, -2));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(0, 1)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(1, 0)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(2, -1)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(3, -2)));
  }


  // -----Pass


  // --------------------------------- getTokenAt Tests ------------------------------------------

  @Test
  public void testGetTokenAtThrowsHighR() {
    assertThrows(IllegalArgumentException.class, () -> model.getTokenAt(
            new HexCoords(0, 10)));
  }

  @Test
  public void testGetTokenAtThrowsHighQ() {
    assertThrows(IllegalArgumentException.class, () -> model.getTokenAt(
            new HexCoords(10, 0)));
  }

  @Test
  public void testGetTokenAtThrowsLowR() {
    assertThrows(IllegalArgumentException.class, () -> model.getTokenAt(
            new HexCoords(0, -10)));
  }

  @Test
  public void testGetTokenAtThrowsLowQ() {
    assertThrows(IllegalArgumentException.class, () -> model.getTokenAt(
            new HexCoords(-10, 0)));
  }

  @Test
  public void testGetTokenAtThrowsInvalidCoords() {
    assertThrows(IllegalArgumentException.class, () -> model.getTokenAt(
            new HexCoords(-2, -2)));
  }

  @Test
  public void testGetEmptyCellReturnsNull() {
    assertEquals(TokenStatus.EMPTY, model.getTokenAt(new HexCoords(0, 0)));
  }

  @Test
  public void testGetBlackCellReturnsBlack() {
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(0, -1)));
  }

  @Test
  public void testGetWhiteCellReturnsWhite() {
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(1, -1)));
  }

  @Test
  public void testGetFlippedWhiteGivesBlack() {
    model.placeToken(new HexCoords(1, -2));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(1, -1)));
  }

  @Test
  public void testGetFlippedBlackGivesWhite() {
    model.pass();
    model.placeToken(new HexCoords(1, -2));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(0, -1)));
  }


  @Test
  public void testBlackScoreUpdates() {
    model.placeToken(new HexCoords(2, -1));
    assertEquals(5, model.getScoreBlack());
  }

  @Test
  public void testWhiteScoreUpdates() {
    model.pass();
    model.placeToken(new HexCoords(-1, 2));
    assertEquals(5, model.getScoreWhite());
  }

  @Test
  public void testPointsSteal() {
    assertEquals(3, model.getScoreBlack());
    assertEquals(3, model.getScoreWhite());
    model.placeToken(new HexCoords(2, -1));
    assertEquals(5, model.getScoreBlack());
    assertEquals(2, model.getScoreWhite());
    model.placeToken(new HexCoords(-1, 2));
    assertEquals(4, model.getScoreBlack());
    assertEquals(4, model.getScoreWhite());
  }

  @Test
  public void testPointsStolenWithMutipleSandwiches() {
    model.placeToken(new HexCoords(2, -1));
    assertEquals(5, model.getScoreBlack());
    assertEquals(2, model.getScoreWhite());
    model.placeToken(new HexCoords(3, -2));
    assertEquals(3, model.getScoreBlack());
    assertEquals(5, model.getScoreWhite());
  }

  /**
   * Tests that a board built with a larger side length returns the correct side length.
   */
  @Test
  public void testSideLengthDif() {
    Reversi hr = new HexReversi(100);
    assertEquals(100, hr.getSideLength());
  }

  //------- All direction sandwich tests
  @Test
  public void testSandwichUpLeft() {
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(1, -1)));
    model.placeToken(new HexCoords(1, -2));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(1, -1)));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(1, -2)));
  }

  @Test
  public void testSandwichUpRight() {
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(0, -1)));
    model.pass();
    model.placeToken(new HexCoords(1, -2));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(1, -2)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(0, -1)));
  }

  @Test
  public void testSandwichLeft() {
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(0, -1)));
    model.pass();
    model.placeToken(new HexCoords(-1, -1));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(0, -1)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(-1, -1)));
  }

  @Test
  public void testSandwichRight() {
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(1, -1)));
    model.placeToken(new HexCoords(2, -1));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(1, -1)));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(2, -1)));
  }

  @Test
  public void testSandwichDownLeft() {
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(-1, 0)));
    model.placeToken(new HexCoords(-2, 1));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(-1, 0)));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(-2, 1)));
  }

  @Test
  public void testSandwichDownRight() {
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(1, 0)));
    model.pass();
    model.placeToken(new HexCoords(1, 1));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(1, 1)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(1, 0)));
  }

  /**
   * This is a test to ensure that just because a white toke is between two
   * black tokens does not mean it gets flipped. For example, if White flips a Black token that
   * is in between two other Black tokens, that token stays WHITE.
   */
  @Test
  public void testSandwichNonExclusive() {
    model.placeToken(new HexCoords(1, 1));
    model.placeToken(new HexCoords(1, 2));
    model.placeToken(new HexCoords(2, -1));
    model.placeToken(new HexCoords(1, -2));
    //These tokens are in a row, but still alternate
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(2, -1)));
    assertEquals(TokenStatus.WHITE, model.getTokenAt(new HexCoords(1, 0)));
    assertEquals(TokenStatus.BLACK, model.getTokenAt(new HexCoords(0, 1)));
  }

  @Test
  public void testLegalMove() {
    assertTrue(model.isMoveLegal(new HexCoords(1, 1)));
  }

  @Test
  public void testIllegalMoveOnBoard() {
    assertFalse(model.isMoveLegal(new HexCoords(0, 0)));
  }

  @Test
  public void testIllegalMoveOffBoard() {
    assertFalse(model.isMoveLegal(new HexCoords(-2, -2)));
  }

  @Test
  public void testIsMoveLegalBadCoords() {
    assertFalse(model.isMoveLegal(new HexCoords(100, -100)));
  }


  @Test
  public void testCopyConstructorBoardImmutable() {
    ReversiModel newMod = new HexReversi(model);
    newMod.placeToken(new HexCoords(1, -2));
    assertNotEquals(model.getTokenAt(new HexCoords(1, -1)),
            newMod.getTokenAt(new HexCoords(1, -1)));
  }


  //-------- valueOfMove -------//

  @Test
  public void testValueOf() {
    assertEquals(1, model.valueOfMove(new HexCoords(1, -2)));
  }

  @Test
  public void testValueOfMultipleFlips() {
    model.placeToken(new HexCoords(-2, 1));
    assertEquals(2, model.valueOfMove(new HexCoords(-3, 1)));
  }

  @Test
  public void testValueOfInvalidMoveThrows() {
    assertThrows(IllegalArgumentException.class, () ->
            model.valueOfMove(new HexCoords(0, -3)));
  }
}
