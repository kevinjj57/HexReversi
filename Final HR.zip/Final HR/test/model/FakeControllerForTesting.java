package model;

import cs3500.reversi.controller.IController;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.model.ReversiROM;
import cs3500.reversi.utils.ICoords;
import cs3500.reversi.utils.TokenStatus;

/**
 * A bogus version of the controller used for testing.
 */
public class FakeControllerForTesting implements IController {

  private TokenStatus color;

  public FakeControllerForTesting(ReversiModel rm) {
    rm.addMoveListener(this);
  }

  /**
   * Ends the game. Displays the message for the end of the game, either a tie or a black or
   * white win.
   */
  @Override
  public void gameOver() {
    //Purposefully left blank.
  }

  /**
   * Set's the player to be the current turn.
   */
  @Override
  public void yourTurn() {
    //Purposefully left blank.
  }

  /**
   * Updates the view with the new updates.
   */
  @Override
  public void refreshAll() {
    //Purposefully left blank.
  }

  /**
   * The color of the player.
   *
   * @return the color
   */
  @Override
  public TokenStatus getColor() {
    if (color == null) {
      throw new IllegalStateException("Color not yet assigned");
    }
    return color;
  }

  /**
   * Assigns the given color to this Controller.
   *
   * @param color the color you wish to give this controller.
   * @throws IllegalArgumentException if the given color is EMPTY.
   * @throws IllegalStateException    if the color has already been assigned.
   */
  @Override
  public void assignColor(TokenStatus color)
          throws IllegalArgumentException, IllegalStateException {
    if (this.color != null) {
      throw new IllegalStateException("Color already assigned");
    }
    this.color = color;
  }

  @Override
  public void pass() {
    //Purposefully left blank.
  }

  @Override
  public void placeToken(ICoords hc) {
    //Purposefully left blank.
  }

  @Override
  public ReversiROM getROM() {
    return null;
  }
}
