package model.square;

import cs3500.reversi.model.SquareReversi;
import model.TestModel;

/**
 * Tests for a square model.
 */
public class SquareModelTests extends TestModel {

  public SquareModelTests() {
    super();
    model = new SquareReversi(4);
  }
}
