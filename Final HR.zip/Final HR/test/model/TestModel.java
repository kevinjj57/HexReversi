package model;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import cs3500.reversi.board.IBoard;
import cs3500.reversi.utils.TokenStatus;
import cs3500.reversi.utils.HexCoords;
import cs3500.reversi.model.ReversiModel;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;


/**
 * Tester class for the HexReversiModel.
 */
public abstract class TestModel {
  // instance variable that we can use to initialize a new HexReversi for every test
  protected ReversiModel model;


  @Before
  public void initializeHexReversi() {
    new FakeControllerForTesting(model);
    new FakeControllerForTesting(model);
    model.startGame();
  }




  // ----------------------------------- startGame Tests ------------------------------------------

  @Test
  public void testStartGameTwice() {
    assertThrows(IllegalStateException.class, () -> model.startGame());
  }


  // -------------------------------Score---------------------------------------------------------

  @Test
  public void testInitialScore() {
    assertEquals(3, model.getScoreBlack());
    assertEquals(3, model.getScoreWhite());
  }

  //-----------------------------------Game Over

  @Test
  public void testGameOverBeginsFalse() {
    assertFalse(model.isGameOver());
  }

  @Test
  public void testDoublePassGameOver() {
    model.pass();
    assertFalse(model.isGameOver());
    model.pass();
    assertTrue(model.isGameOver());
  }

  /**
   * Tests that non-sequential passes does not cause game to end.
   */
  @Test
  public void testPassNotBack2Back() {
    model.pass();
    model.placeToken(new HexCoords(-1, -1));
    model.pass();
    assertFalse(model.isGameOver());
  }

  /**
   * Tests that you cannot place a token after the game ends.
   */
  @Test
  public void testGameOverNoPlaceToken() {
    model.pass();
    model.pass();
    assertThrows(IllegalStateException.class, () ->
            model.placeToken(new HexCoords(2, -1)));
  }

  /**
   * Tests that you pass after the game ends.
   */
  @Test
  public void testGameOverNoPassToken() {
    model.pass();
    model.pass();
    assertThrows(IllegalStateException.class, () -> model.pass());
  }

  //-- sidelength

  /**
   * Tests that a standard game with side length 4 returns the correct side length.
   */
  @Test
  public void testSideLengthBase() {
    assertEquals(4, model.getSideLength());
  }


  //-----------getBoard--------//

  /**
   * Test works because if getBoard returned the actual board object, the boards would be
   * double equals to each other.
   */
  @Test
  public void testGetBoardReturnsCopy() {
    assertFalse(model.getBoard() == model.getBoard());
  }

  @Test
  public void testGetBoardImmutable() {
    IBoard board = model.getBoard();
    board.addToBoard(new HexCoords(0, 0), TokenStatus.BLACK);
    assertEquals(TokenStatus.EMPTY, model.getBoard().getPieceAt(new HexCoords(0, 0)));
  }

  //-------- isMoveLegal ------//


  @Test
  public void testIsMoveLegalNullCoords() {
    assertThrows(IllegalArgumentException.class, () -> model.isMoveLegal(null));
  }

  @Test
  public void testIsMoveLegalChecksForTheTurnPlayer() {
    model.placeToken(new HexCoords(1, -2));
    assertFalse(model.isMoveLegal(new HexCoords(-1, -1)));
    assertTrue(model.isMoveLegal(new HexCoords(2, -3)));
  }

  //-------  getPossibleMoves ------//

  @Test
  public void testContainsCorrectPossibleBlackMoves() {
    List<Boolean> lob = new ArrayList<>();
    lob.add(model.getPossibleMoves().contains(new HexCoords(1, -2)));
    lob.add(model.getPossibleMoves().contains(new HexCoords(-1, -1)));
    lob.add(model.getPossibleMoves().contains(new HexCoords(2, -1)));
    lob.add(model.getPossibleMoves().contains(new HexCoords(-2, 1)));
    lob.add(model.getPossibleMoves().contains(new HexCoords(1, 1)));
    lob.add(model.getPossibleMoves().contains(new HexCoords(-1, 2)));
    assertTrue(lob.stream().allMatch(b -> b));
  }

  @Test
  public void testContainsAllPossibleMovesAfterOneMove() {
    List<Boolean> lob = new ArrayList<>();
    model.placeToken(new HexCoords(1, -2));
    lob.add(model.getPossibleMoves().contains(new HexCoords(2, -3)));
    lob.add(model.getPossibleMoves().contains(new HexCoords(2, -1)));
    lob.add(model.getPossibleMoves().contains(new HexCoords(-2, 1)));
    lob.add(model.getPossibleMoves().contains(new HexCoords(-1, 2)));
    assertTrue(lob.stream().allMatch(b -> b));
  }

  @Test
  public void testGPMorder() {
    model.placeToken(new HexCoords(1, -2));
    List<HexCoords> exp = new ArrayList<>();
    exp.add(new HexCoords(2, -3));
    exp.add(new HexCoords(2, -1));
    exp.add(new HexCoords(-2, 1));
    exp.add(new HexCoords(-1, 2));
    assertEquals(exp, model.getPossibleMoves());
  }

  @Test
  public void testContainsCorrectPossibleWhiteMoves() {
    model.pass();
    List<Boolean> lob = new ArrayList<>();
    lob.add(model.getPossibleMoves().contains(new HexCoords(1, -2)));
    lob.add(model.getPossibleMoves().contains(new HexCoords(-1, -1)));
    lob.add(model.getPossibleMoves().contains(new HexCoords(2, -1)));
    lob.add(model.getPossibleMoves().contains(new HexCoords(-2, 1)));
    lob.add(model.getPossibleMoves().contains(new HexCoords(1, 1)));
    lob.add(model.getPossibleMoves().contains(new HexCoords(-1, 2)));
    assertTrue(lob.stream().allMatch(b -> b));
  }

  @Test
  public void testOrderOfPossibileMovesTopLeftToBottomRight() {
    List<HexCoords> exp = new ArrayList<>();
    exp.add(new HexCoords(1, -2));
    exp.add(new HexCoords(-1, -1));
    exp.add(new HexCoords(2, -1));
    exp.add(new HexCoords(-2, 1));
    exp.add(new HexCoords(1, 1));
    exp.add(new HexCoords(-1, 2));
    assertEquals(exp, model.getPossibleMoves());
  }

  //-------- copyConstructor----//
  @Test
  public void testCopyModelIdentical() {
    ReversiModel newMod = model.copy();
    assertEquals(model.whoseTurn(), newMod.whoseTurn());
    assertEquals(model.getPossibleMoves(), newMod.getPossibleMoves());
    assertEquals(model.isGameOver(), newMod.isGameOver());
    assertEquals(model.getSideLength(), newMod.getSideLength());
    assertEquals(model.getScoreBlack(), newMod.getScoreBlack());
    assertEquals(model.getScoreWhite(), newMod.getScoreWhite());
  }

  @Test
  public void testCopyConstuctorPlayersImmutable() {
    ReversiModel newMod = model.copy();
    newMod.pass();
    assertNotEquals(model.whoseTurn(), newMod.whoseTurn());
  }

}
