package strats;

import org.junit.Before;
import org.junit.Test;

import cs3500.reversi.model.HexReversi;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.player.AI;
import cs3500.reversi.player.IPlayer;
import cs3500.reversi.strategy.GetHighestScore;
import cs3500.reversi.utils.HexCoords;
import model.FakeControllerForTesting;

import static junit.framework.TestCase.assertEquals;

/**
 * Class used to test our AI follows strategies.
 */
public class TestAI {

  ReversiModel model;
  IPlayer ai;

  @Before
  public void setModel() {
    model = new HexReversi(4);
  }

  @Test
  public void testAIFollowsDefaultTopLeft() {
    ai = new AI();
    ControllerForStratTests cont = new ControllerForStratTests(model, ai);
    new FakeControllerForTesting(model);
    model.startGame();
    //Ai places a move at the top left first given move if it has no strats.
    assertEquals(model.getTokenAt(cont.validMoves.get(0)), ai.getColor());
  }

  @Test
  public void testAIGetsHighestScore() {
    ai = new AI(new GetHighestScore());
    new FakeControllerForTesting(model);
    ControllerForStratTests cont = new ControllerForStratTests(model, ai);
    model.startGame();
    model.placeToken(new HexCoords( -1, 2));
    assertEquals(model.getTokenAt(new GetHighestScore().getValidMoves(model,
            model.getPossibleMoves()).get(0)), ai.getColor());
  }
}
